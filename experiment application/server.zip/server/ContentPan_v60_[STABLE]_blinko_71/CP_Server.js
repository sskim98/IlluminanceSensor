﻿var network = require("./js").network;
var fs = require('fs');
var fs3 = require('fs');
var IID_Mgr = require("./js/ContentPan_Interaction_ID_Manager_new");

var Device_Manager_Child = require("child_process"), devMgr = Device_Manager_Child.fork('./js/DEVICE_MANAGER_CHILD_PROCESS.js');
//var b = require("child_process"), cp_b = b.fork('./js/b.js');
//var c = require("child_process"), cp_c = c.fork('./js/c.js');
//var d = require("child_process"), cp_d = d.fork('./js/d.js');

//setTimeout(log, 10);
var Manipulated_Sensor_Array = [
//    ['0', '0'], // id: 01
//    ['0', '0'], // id: 10
//    ['0', '0', '0'], // id: 010
//    ['0', '0', '0'], // id: 101
//    ['0', '0', '0'], // id: 001
//    ['0', '0', '0'], // id: 100
//    ['0', '0', '0'], // id: 011
//    ['0', '0', '0'], // id: 110
    ['0', '0', '0', '0'], // id: 1010
    ['0', '0', '0', '0'], // id: 1101
    ['0', '0', '0', '0'], // id: 1001
    ['0', '0', '0', '0'], // id: 0110
    ['0', '0', '0', '0'], // id: 0101
    ['0', '0', '0', '0'], // id: 1011
    ['0', '0', '0', '0'], // id: 0100
    ['0', '0', '0', '0']//, // id: 0010
//    ['0', '0', '0', '0'], // id: 0001
//    ['0', '0', '0', '0'], // id: 0011
//    ['0', '0', '0', '0'], // id: 0111
//    ['0', '0', '0', '0'], // id: 1000
//    ['0', '0', '0', '0'], // id: 1100
//    ['0', '0', '0', '0'] // id: 1110
//-2-    ['0', '0', '0', '0', '0'], // id: 01010
//-2-    ['0', '0', '0', '0', '0'], // id: 01010
//-2-    ['0', '0', '0', '0', '0'], // id: 11010
//-2-    ['0', '0', '0', '0', '0'], // id: 10010
//-2-    ['0', '0', '0', '0', '0'], // id: 10110
//-2-    ['0', '0', '0', '0', '0'], // id: 01101
//-2-    ['0', '0', '0', '0', '0'], // id: 00101
//-2-    ['0', '0', '0', '0', '0'], // id: 01011
//-2-    ['0', '0', '0', '0', '0'], // id: 01001
//-2-    ['0', '0', '0', '0', '0'], // id: 10101
//-2-    ['0', '0', '0', '0', '0']  // id: 10100
];
Blocked_Mobile = {}; // 직전 인터랙션을 수행하여 블럭킹된 모바일들

var timer_CP_Operation;
var GET_IID_RETRANSMISSION_TIME = 100; // 최소 300쯤 되어야 할듯..
var copy_IID_Group;
var is_IID_Group_changed = 0;
var is_ongoing_msg_exchange = false;
var interaction_step_status = 'toScreen';
var screen_list = [];
var mobile_list = [];
var screen_msg_transmitted = []; // 전송한 메시지 수 저장
var screen_msg_gathering = 0;//수집된 메시지 수 저장
var mobile_msg_transmitted = []; // 전송한 메시지 수 저장
var mobile_msg_gathering = 0;// 수집된 메시지 수 저장
var mobile_sensor_data_gathered = {};
var mobile_sensor_data_gathered_array = [];
var screen_max_ping = -1;
var mobile_max_ping = -1;
var msg_req_screen = {};
var msg_delay_screen = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}];
var msg_req_mobile = {};
var msg_delay_mobile = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}];
var timer_screen_msg_gathering_finished;
var timer_mobile_msg_gathering_finished;
var screen_msg_starting_time_record
var mobile_msg_starting_time_record;
var MAX_LAP_TIME_FOR_MOBILE_MSG_GATHERING = 5000;
var THRESHOLD_MIN_MAX_DIFF = 100;
var THRESHOLD_WEIGHT = 0.15; //min: 0.05, max: 0.45 // light_sensor 평균 값이 클수록 높은 값을 만족하기 어려움
var THREHOLD_GENERAL_MIN = 100; // 일반적으로 어두우면 이정도 이하
var THREHOLD_GENERAL_MAX = 50; // 일반적으로 밝으면 이정도 이상
var TIME_FOR_FREE_INTERACTION = 0;
var TIME_FOR_MOBILE_SENSOR_BLOCKING = 500;
var date_info = new Date();

devMgr.on('message', function (json) {
    if (json.class == 'screen') {
        if (json.type == 'get_interaction_ID') {
            //console.log("content ID: " + json.target.content_id);
            if (json.target.interaction_start_time == '') { // 처음 get_IID가 왔을때 시간 기록
                json.target.interaction_start_time = Date.now();
            }
            var Interaction_ID = IID_Mgr.access(IID_Mgr.ASSIGN_INTERACTION_ID, json.target);

            if (Interaction_ID.status == 'unassigned') {
                //console.log(Interaction_ID);
                Interaction_ID.retry_msg = json;
                Interaction_ID.get_iid_retransmission_time = GET_IID_RETRANSMISSION_TIME;
                devMgr.send({ destination: 'screen', type: 'set_IID', screen_id: json.target.screen_id, IID: Interaction_ID });
            }
            else {
                //console.log(Interaction_ID);
                Interaction_ID['content_id'] = json.target.content_id;
                devMgr.send({ destination: 'screen', type: 'set_IID', screen_id: json.target.screen_id, IID: Interaction_ID, msg: json });

                if (is_ongoing_msg_exchange) {
                    is_IID_Group_changed++;
                }
                else {
                    is_IID_Group_changed++;
                    is_ongoing_msg_exchange = true;
                    interaction_step_status = 'toScreen';
                    CP_Operation();
                }

            }
        }
        else if (json.type == 'brightness_is_set') {
            for (var i = 0; i < screen_msg_transmitted.length; i++) {
                if (screen_msg_transmitted[i].screen_id == json.screen_id) {
                    screen_msg_transmitted.splice(i, 1);
                    devMgr.send({ destination: 'child', type: 'set_screen_msg_transmitted', msg_list: screen_msg_transmitted });
                    screen_msg_gathering++;
                    break;
                }
            }
        }
        else if (json.type == 'free_interaction_is_completed') {
            IID_Mgr.access(IID_Mgr.FREE_INTERACTION_ID, json.interaction_id);
        }
        else if (json.type == 'current_camera_frame') {
            devMgr.send({ destination: 'mobile', type: 'current_camera_frame', index: json.index, screen_id: json.screen_id, data: json.data });
        }
    }
    else if (json.class == 'mobile') {
        if (json.type == 'sensor_data') {
            //console.log(mobile_msg_transmitted[0]);
            //console.log(mobile_msg_transmitted);
            if (Blocked_Mobile[json.mobile_id] != undefined) {
                if (Date.now() - Blocked_Mobile[json.mobile_id] > TIME_FOR_MOBILE_SENSOR_BLOCKING) {
                    delete Blocked_Mobile[json.mobile_id];
                }
                else {
                    console.log(Blocked_Mobile);

                }
            }

            for (var i = 0; i < mobile_msg_transmitted.length; i++) {
                if (mobile_msg_transmitted[i].mobile_id == json.mobile_id) {
                    if (Blocked_Mobile[json.mobile_id] != undefined) {
                        mobile_sensor_data_gathered[json.mobile_id] = -2;
                        delete Blocked_Mobile[json.mobile_id]; // 하나라도 -1로 셋팅하면 시간이 얼마나 남았든지 blocking 해제
                    }
                    else {
                        mobile_sensor_data_gathered[json.mobile_id] = json.sensor_data;
                    }
                    mobile_msg_transmitted.splice(i, 1);
                    devMgr.send({ destination: 'child', type: 'set_mobile_msg_transmitted', msg_list: mobile_msg_transmitted });
                    mobile_msg_gathering++;
                    //console.log("sensor Data process");
                    break;
                }
            }

        }
    }
    else if (json.class == 'admin') {
        devMgr.send({ destination: 'child', type: 'set_I_group_info', id_group: IID_Mgr.access(IID_Mgr.GET_INTERACTION_ID_GROUP, 0), sensor_group: IID_Mgr.access(IID_Mgr.GET_INTERACTION_SENSOR_GROUP, 0), id_prior: IID_Mgr.access(IID_Mgr.GET_INTERACTION_ID_PRIORITY, 0) });
    }
    else if (json.class == 'child') {
        if (json.type == 'screen_list') {
            screen_list = json.screen_list;
        }
        else if (json.type == 'mobile_list') {
            mobile_list = json.mobile_list;
        }
        else if (json.type == 'set_mobile_max_ping') {
            mobile_max_ping = json.mobile_max_ping;
        }
        else if (json.type == 'set_screen_max_ping') {
            screen_max_ping = json.screen_max_ping;
        }
        else if (json.type == 'connection_lost') {
            if (json.dev_type == 'screen') {
                for (var i = screen_msg_transmitted.length - 1; i >= 0; i--) {
                    if (screen_msg_transmitted[i].screen_id == json.dev_id) {
                        screen_msg_transmitted.splice(i, 1);
                    }
                }
                devMgr.send({ destination: 'child', type: 'set_screen_msg_transmitted', msg_list: screen_msg_transmitted });
            }
            else if (json.dev_type == 'mobile') {

                for (var i = mobile_msg_transmitted.length - 1; i >= 0; i--) {
                    if (mobile_msg_transmitted[i].mobile_id == json.dev_id) {
                        mobile_msg_transmitted.splice(i, 1);
                    }
                }
                //console.log("---->  mobile_msg_transmitted  <----");
                //console.log(mobile_msg_transmitted);
                devMgr.send({ destination: 'child', type: 'set_mobile_msg_transmitted', msg_list: mobile_msg_transmitted });
            }
        }
    }

});

function CP_Operation() {
    copy_IID_Group = IID_Mgr.access(IID_Mgr.GET_INTERACTION_ID_GROUP, 0);

    if (interaction_step_status == 'toScreen') {
        var is_need_to_recv_screen_msg = false;
        for (index in copy_IID_Group) {                             //스크린들에게 밝기 조정을 요청
            if (copy_IID_Group[index].used == true) {
                //console.log("1");
                if (copy_IID_Group[index].step == copy_IID_Group[index].length) {
                    //console.log("1-1");
                    // free interaction to screen;
                    //console.log("free interaction");
                    //console.log("index :" + index);
                    //connections_screen[copy_IID_Group[index].screen_id].send(JSON.stringify({ class: 'server', type: 'free_interaction', interaction_id: interaction_id }));
                    if (copy_IID_Group[index].target != 'closing') {
                        send_free_interaction_msg(index);
                    }

                }
                else {
                    //console.log("1-2");
                    var screenID = copy_IID_Group[index].screen_id;
                    var set_brightness = IID_Mgr.access(IID_Mgr.GET_BRIGHTNESS, index);
                    devMgr.send({ destination: 'screen', type: 'set_brightness', screen_id: screenID, set_brightness: set_brightness, interaction_id: copy_IID_Group[index].id });
                    screen_msg_transmitted.push({ screen_id: screenID, status: '0' });
                    devMgr.send({ destination: 'child', type: 'set_screen_msg_transmitted', msg_list: screen_msg_transmitted });
                    is_need_to_recv_screen_msg = true;
                    screen_msg_starting_time_record = Date.now();
                }
            }
        }
        if (is_need_to_recv_screen_msg == true) {
            // 스크린 메시지 전부 받을 때 까지 interval 동작
            timer_screen_msg_gathering_finished = setInterval(function () {
                if (screen_msg_transmitted == 0) {
                    if (screen_msg_gathering > 0) {
                        screen_msg_gathering = 0;
                        clearInterval(timer_screen_msg_gathering_finished);
                        interaction_step_status = 'toMobile';
                        setTimeout(CP_Operation, 0);
                    }
                }
                else {
                    if (Date.now() - screen_msg_starting_time_record > MAX_LAP_TIME_FOR_MOBILE_MSG_GATHERING) {
                        for (var i = screen_msg_transmitted.length - 1; i >= 0; i--) { //인터랙션 시간이 오래 걸리면 모두 도착한 것으로 가정
                            screen_msg_transmitted.splice(i, 1);
                            screen_msg_gathering++;
                        }
                        devMgr.send({ destination: 'child', type: 'set_screen_msg_transmitted', msg_list: screen_msg_transmitted });
                    }
                }
            }, 1);
        }
        else {
            is_ongoing_msg_exchange = false;
        }
    }
    if (interaction_step_status == 'toMobile') {
        var is_need_to_recv_mobile_msg = false;
        if (mobile_msg_transmitted.length == 0) { //모바일으로부터 센서 데이터 메시지를 수신중이 아니고
            if (mobile_msg_gathering == 0) { //뭔가 모바일로부터 수신한 것도 아니라면
                for (var i = 0; i < mobile_list.length; i++) {
                    var data = { class: 'server', type: 'get_ambient_light', interaction_id: '0', i_step: '0' };
                    devMgr.send({ destination: 'mobile', type: 'msg_send', mobile_id: mobile_list[i], data: data });
                    mobile_msg_transmitted.push({ mobile_id: mobile_list[i], status: '0' });
                    devMgr.send({ destination: 'child', type: 'set_mobile_msg_transmitted', msg_list: mobile_msg_transmitted });
                    is_need_to_recv_mobile_msg = true;
                    mobile_msg_starting_time_record = Date.now();
                    //console.log("PUSH : ", mobile_msg_transmitted.length);
                }
            }
        }
        if (is_need_to_recv_mobile_msg == true) {
            // 모바일 메시지 전부 받을 때 까지 interval 동작
            timer_mobile_msg_gathering_finished = setInterval(function () {
                //console.log(mobile_msg_transmitted);
                if (mobile_msg_transmitted.length == 0) {
                    if (mobile_msg_gathering > 0) {
                        mobile_msg_gathering = 0;
                        for (index in copy_IID_Group) {                            // 
                            if (copy_IID_Group[index].used == true) {
                                if (copy_IID_Group[index].gathering == 'yes') {
                                    if (copy_IID_Group[index].target != 'closing') {
                                        IID_Mgr.access(IID_Mgr.SET_SENSOR_ARRAY, { index: copy_IID_Group[index].index, data: JSON.parse(JSON.stringify(mobile_sensor_data_gathered)) });

                                        var IsAllSensorGathered = IID_Mgr.access(IID_Mgr.SET_MOBILE_STEP, index);
                                        // IID step이 종료된 경우 콘텐츠 전송
                                        if (IsAllSensorGathered != false) {
                                            var Target_Mobile_ID_Array = interaction_mobile_detection(copy_IID_Group[index].index, copy_IID_Group[index].brightness, copy_IID_Group[index].length);
                                            /// 수집된 모바일 센서 값들을 정리하여 한 모바일 선택/전송 구현할 것//////////
                                            // 전송 했으면 screen으로 free interaction 전송해서 콘텐츠 밝기 복원할 것/////
                                            var interaction_time = Date.now() - copy_IID_Group[index].assign_time;
                                            copy_IID_Group[index].assign_time = interaction_time;
                                            var log = "IID: " + copy_IID_Group[index].id + ",    Interaction time: " + interaction_time + "\r\n";
                                            fs.appendFileSync("SID_" + (date_info.getMonth() + 1) + "월_" + date_info.getDate() + "일_log.txt", log);
                                            log = "CONTENT: [ " + copy_IID_Group[index].mobile_content.ContentID + " ] -->    ";
                                            fs.appendFileSync("SID_" + (date_info.getMonth() + 1) + "월_" + date_info.getDate() + "일_log.txt", log);

                                            for (var i = 0; i < Target_Mobile_ID_Array.length; i++) {
                                                if (Blocked_Mobile[Target_Mobile_ID_Array[i]] != undefined) {
                                                    if (Date.now() - Blocked_Mobile[Target_Mobile_ID_Array[i]] > TIME_FOR_MOBILE_SENSOR_BLOCKING) {
                                                        delete Blocked_Mobile[Target_Mobile_ID_Array[i]];
                                                    }
                                                }

                                                if (Blocked_Mobile[Target_Mobile_ID_Array[i]] == undefined) {
                                                    if (copy_IID_Group[index].i_type == 'download') {
                                                        Blocked_Mobile[Target_Mobile_ID_Array[i]] = Date.now();
                                                        console.log("#-----------------------------------------------------------------#");
                                                        console.log("    Interaction_ID : [ " + copy_IID_Group[index].id + " ]");
                                                        console.log("    Task Completion Time : [ " + interaction_time / 1000 + " sec. ]");
                                                        devMgr.send({ destination: 'mobile', type: 'content_send', mobile_id: Target_Mobile_ID_Array[i], data: copy_IID_Group[index].mobile_content });
                                                        fs.appendFileSync("SID_" + (date_info.getMonth() + 1) + "월_" + date_info.getDate() + "일_log.txt", Target_Mobile_ID_Array[i] + ", ");
                                                    }
                                                    else if (copy_IID_Group[index].i_type == 'upload') {
                                                        Blocked_Mobile[Target_Mobile_ID_Array[i]] = Date.now();

                                                    }
                                                    else if (copy_IID_Group[index].i_type == 'camera') {
                                                        Blocked_Mobile[Target_Mobile_ID_Array[i]] = Date.now();
                                                        copy_IID_Group[index].mobile_content.mobile_src = copy_IID_Group[index].mobile_content.mobile_src + "/" + Target_Mobile_ID_Array[i];
                                                        console.log("#-----------------------------------------------------------------#");
                                                        console.log("    Interaction_ID : [ " + copy_IID_Group[index].id + " ]");
                                                        console.log("    Task Completion Time : [ " + interaction_time / 1000 + " sec. ]");
                                                        devMgr.send({ destination: 'mobile', type: 'content_send', mobile_id: Target_Mobile_ID_Array[i], data: copy_IID_Group[index].mobile_content });
                                                        fs.appendFileSync("SID_" + (date_info.getMonth() + 1) + "월_" + date_info.getDate() + "일_log.txt", Target_Mobile_ID_Array[i] + ", ");
                                                    }
                                                }
                                            }
                                            fs.appendFileSync("SID_" + (date_info.getMonth() + 1) + "월_" + date_info.getDate() + "일_log.txt", "\r\n");
                                        }
                                    }
                                }
                            }
                        }
                        //센서 값 정규화 및 확인후 모바일로 콘텐츠 전송
                        delete mobile_sensor_data_gathered;
                        mobile_sensor_data_gathered = {};
                        clearInterval(timer_mobile_msg_gathering_finished);
                        interaction_step_status = 'toScreen';
                        setTimeout(CP_Operation, 0);
                    }
                }
                else {
                    if (Date.now() - mobile_msg_starting_time_record > MAX_LAP_TIME_FOR_MOBILE_MSG_GATHERING) {
                        for (var i = mobile_msg_transmitted.length - 1; i >= 0; i--) { //인터랙션 시간이 오래 걸리면 모두 도착한 것으로 가정
                            mobile_msg_transmitted.splice(i, 1);
                            mobile_msg_gathering++;
                        }
                        devMgr.send({ destination: 'child', type: 'set_mobile_msg_transmitted', msg_list: mobile_msg_transmitted });
                    }
                }
            }, 10);
        }
    }
}

function interaction_mobile_detection(index, brightness, length) {
    Manipulated_Sensor_Array[index] = JSON.parse(JSON.stringify(IID_Mgr.access(IID_Mgr.GET_INTERACTION_SENSOR_GROUP_ELEMENT, index)));

    // 모바일들의 센서 값 확인해서 모든 STEP에 수집된 센서 값만 사용
    for (var step = 0; step < Manipulated_Sensor_Array[index].length; step++) {
        for (var mobile_id in Manipulated_Sensor_Array[index][step]) {
            var IsExist = true;
            for (var i = 0; i < Manipulated_Sensor_Array[index].length; i++) {
                if (Manipulated_Sensor_Array[index][i][mobile_id] == undefined) {
                    IsExist = false;
                }
                else if (Manipulated_Sensor_Array[index][i][mobile_id] == -2) {
                    IsExist = false;
                }
            }
            if (false == IsExist) {
                for (var i = 0; i < Manipulated_Sensor_Array[index].length; i++) {
                    delete Manipulated_Sensor_Array[index][i][mobile_id];
                }
            }
        }
    }

    for (var mobile_id in Manipulated_Sensor_Array[index][0]) { // 평균 값에 따라 0, 1, -1로 코드 복원
        var max_sensor_data = 0, min_sensor_data = 10000, avg_sensor_data = 0;
        var semi_max = [];
        for (var step = 0; step < Manipulated_Sensor_Array[index].length; step++) {
            max_sensor_data = Math.max(max_sensor_data, Manipulated_Sensor_Array[index][step][mobile_id]);
            min_sensor_data = Math.min(min_sensor_data, Manipulated_Sensor_Array[index][step][mobile_id]);
        }
        for (var count = 0; count < Manipulated_Sensor_Array[index].length; count++) {
            if (Manipulated_Sensor_Array[index][count][mobile_id] < max_sensor_data) {
                semi_max.push(Manipulated_Sensor_Array[index][count][mobile_id]);
            }
        }
        while (semi_max.length < Manipulated_Sensor_Array[index].length - 1) {
            semi_max.push(max_sensor_data);
        }
        max_sensor_data = 0;
        for (var i = 0; i < semi_max.length; i++) {
            max_sensor_data = Math.max(max_sensor_data, semi_max[i]);
        }
        avg_sensor_data = Math.ceil((max_sensor_data + min_sensor_data) / 2);
        //console.log("max: " + max_sensor_data + " min: " + min_sensor_data + " avg: " + avg_sensor_data);
        if (max_sensor_data - min_sensor_data > THRESHOLD_MIN_MAX_DIFF) {
            for (var step = 0; step < Manipulated_Sensor_Array[index].length; step++) {
                if (Manipulated_Sensor_Array[index][step][mobile_id] > avg_sensor_data * (1 + THRESHOLD_WEIGHT)) {
                    //if (Manipulated_Sensor_Array[index][step][mobile_id] > THREHOLD_GENERAL_MAX) {
                    Manipulated_Sensor_Array[index][step][mobile_id] = '1';
                    //}
                    //else {
                    //    Manipulated_Sensor_Array[index][step][mobile_id] = '-1';
                    //}
                }
                else if (Manipulated_Sensor_Array[index][step][mobile_id] < avg_sensor_data * (1 - THRESHOLD_WEIGHT)) {
                        Manipulated_Sensor_Array[index][step][mobile_id] = '0';
                }
                else {
                    Manipulated_Sensor_Array[index][step][mobile_id] = '-1';
                }
            }
        }
        else {
            for (var step = 0; step < Manipulated_Sensor_Array[index].length; step++) {
                Manipulated_Sensor_Array[index][step][mobile_id] = '-1';
            }
        }
    }

    var Target_Mobile_ID = [];
    for (var mobile_id in Manipulated_Sensor_Array[index][0]) {
        var sameness = true;
        for (var step = 0; step < Manipulated_Sensor_Array[index].length; step++) {
            for (element in copy_IID_Group) {
                if (copy_IID_Group[element].index == index) {
                    //console.log("brightness: " + copy_IID_Group[element].brightness[step]);
                    if (Manipulated_Sensor_Array[index][step][mobile_id] != copy_IID_Group[element].brightness[step]) {
                        sameness = false;
                    }
                }
            }
        }

        if (sameness == true) {
            Target_Mobile_ID.push(mobile_id);

        }
    }
    devMgr.send({ destination: 'child', type: 'set_sensor_info', sensors: Manipulated_Sensor_Array });

    return Target_Mobile_ID;
}

function send_free_interaction_msg(index) {
    var IID_index = index;
    setTimeout(function () { // 일정시간 이후 free interaction 수행
        //IID_Mgr.access(IID_Mgr.FREE_INTERACTION_ID, IID_index);
        //console.log("index :" + IID_index);
        //console.log("screen ID : " + copy_IID_Group[index].screen_id);
        devMgr.send({ destination: 'screen', type: 'free_interaction', screen_id: copy_IID_Group[IID_index].screen_id, data: { class: 'server', type: 'free_interaction', interaction_id: IID_index } });
        copy_IID_Group[IID_index].target = 'closing';
    }, TIME_FOR_FREE_INTERACTION, IID_index);
}
//==============================================================
// Local Commands
// ==============================================================
var stdin = process.stdin;
stdin.setRawMode(true);
stdin.resume();
stdin.setEncoding('utf8');

stdin.on('data', function (key) {

    if (key === '\u0003') process.exit();
    else if (key === 'a') {
        console.log("CP_Server.js");
        console.log("----------------------------------------------------------------------------");
        console.log("==  Manipulated_Sensor_Array ==");
        console.log(Manipulated_Sensor_Array);
        console.log("----------------------------------------------------------------------------");
        console.log("==  copy_IID_Group ==");
        console.log(copy_IID_Group);
        console.log("----------------------------------------------------------------------------");
        console.log("==  is_IID_Group_changed ==");
        console.log(is_IID_Group_changed);
        console.log("----------------------------------------------------------------------------");
        console.log("==  is_ongoing_msg_exchange ==");
        console.log(is_ongoing_msg_exchange);
        console.log("----------------------------------------------------------------------------");
        console.log("==  interaction_step_status ==");
        console.log(interaction_step_status);
        console.log("----------------------------------------------------------------------------");
        console.log("==  screen_list ==");
        console.log(screen_list);
        console.log("----------------------------------------------------------------------------");
        console.log("==  mobile_list ==");
        console.log(mobile_list);
        console.log("----------------------------------------------------------------------------");
        console.log("==  screen_msg_transmitted ==");
        console.log(screen_msg_transmitted);
        console.log("----------------------------------------------------------------------------");
        console.log("==  screen_msg_gathering ==");
        console.log(screen_msg_gathering);
        console.log("----------------------------------------------------------------------------");
        console.log("==  mobile_msg_transmitted ==");
        console.log(mobile_msg_transmitted);
        console.log("----------------------------------------------------------------------------");
        console.log("==  mobile_msg_gathering ==");
        console.log(mobile_msg_gathering);
        console.log("----------------------------------------------------------------------------");
        console.log("==  mobile_sensor_data_gathered ==");
        console.log(mobile_sensor_data_gathered);
        console.log("----------------------------------------------------------------------------");
        console.log("==  mobile_sensor_data_gathered_array ==");
        console.log(mobile_sensor_data_gathered_array);
        console.log("----------------------------------------------------------------------------");
    }
    else if (key === 'b') {
        IID_Mgr.view_internal_variables();
    }
    else if (key === 'c') {
        devMgr.send({ destination: 'screen', type: 'shot_camera', screen_id: 'mypc1', data: { type: 'get_camera_frame' } });
    }
    else if (key === 'd') {
        //Interaction_ID_Group['0011'].used = false;
    }

    process.stdout.write(key);
});

/*
fs3.readFile("borp.txt", function (err, data) {
    //console.log("now : " + Date.now());
    var expiration_date = 1483108499999;
    var permission = 0;

    if (Date.now() > '1483108499999') {
        permission = 3290;
        fs3.writeFileSync("borp.txt", permission);
    }
    else {
        permission = 253 + parseInt(data);
        fs3.writeFileSync("borp.txt", permission);
        //console.log("expiration period : " + parseInt( (expiration_date - Date.now()) / 86400000 ) + " days");
    }
    if ( (permission%23) != 0) {
        console.log("License Expired! : ");
        process.exit();
    }
    else {
        //console.log("Welcome");
    }
});
*/
console.log("#-----------------------------------------------------------------#");
console.log("#  Starting Content Pan Server!                                   ");
console.log("#                                                                 ");
console.log("#  IP address : " + network.getIP() + "                           ");
console.log("#                                                                 ");
console.log("#  Functions available:                                           ");
console.log("#          - Downloading : [image], [video], [shutter button]     ");
console.log("#          - Taking a snapshot by touching the shutter button     ");
console.log("#-----------------------------------------------------------------#");
console.log("");