
// Arguments �Ľ�

var arguments = {};

for (var i = 2; i < process.argv.length ; i+=2 )
{
	arguments[process.argv[i]] =  process.argv[i+1];
}

if (!arguments["-n"])
{
	console.log("source name required");
}

if (!arguments["-p"])
{
	console.log("password required");
}

var key = arguments["-p"];
var source_file = arguments["-n"];


// �ҽ����� ���ڵ� & ����
var fs = require('fs');
var crypto = require("crypto");
var algorithm = "aes256";
var source = fs.readFileSync(source_file, 'utf8');
var cipher = crypto.createCipher(algorithm, key);
var encrypted = cipher.update(source, "utf8", "hex") + cipher.final("hex"); 
fs.writeFile("CP.kaist", encrypted); 
