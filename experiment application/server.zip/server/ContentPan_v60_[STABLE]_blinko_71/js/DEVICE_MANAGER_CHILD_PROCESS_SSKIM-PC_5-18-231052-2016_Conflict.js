﻿var network = require("./network");
var fs = require('fs');
var http = require('http');

var Interaction_ID_Group;
var Interaction_Sensor_Group;
var Interaction_ID_Priority;
var Manipulated_Sensor_Array;
var screen_msg_transmitted;
var mobile_msg_transmitted;
var json_msg_counter = 0;
var camera_snapshot_buffer = {};
var sse_connectionStatus = "disconnected";

process.on('message', function (msg) {
    if (msg.destination == 'child') {
        if(msg.type == 'set_I_group_info') {
            Interaction_ID_Group = msg.id_group;
            Interaction_Sensor_Group = msg.sensor_group;
            Interaction_ID_Priority = msg.id_prior;
        }
        else if (msg.type == 'set_sensor_info') {
            Manipulated_Sensor_Array = msg.sensors;
        }
        else if (msg.type == 'get_mobile_max_ping') {
            process.send({ class: 'child', type: 'set_mobile_max_ping', mobile_max_ping: ping_delay_mobile_max });
        }
        else if (msg.type == 'get_screen_max_ping') {
            process.send({ class: 'child', type: 'set_screen_max_ping', screen_max_ping: ping_delay_screen_max });
        }
        else if (msg.type == 'set_screen_msg_transmitted') {
            screen_msg_transmitted = msg.msg_list;
        }
        else if (msg.type == 'set_mobile_msg_transmitted') {
            mobile_msg_transmitted = msg.msg_list;
        }
    }
    else if (msg.destination == 'screen') {
        if (connections_screen[msg.screen_id] != undefined) {
            if (msg.type == 'set_brightness') {
                if (connections_screen[msg.screen_id].readyState == '1') {
                    connections_screen[msg.screen_id].send(JSON.stringify(msg.set_brightness));
                }
                if ((connections_admin != undefined) && (connections_admin.readyState == '1')) {
                    connections_admin.send(JSON.stringify({ class: 'server', type: 'jsondataR', data: msg.set_brightness }));
                }
            }
            else if (msg.type == 'set_IID') {
                if (connections_screen[msg.screen_id].readyState == '1') {
                    connections_screen[msg.screen_id].send(JSON.stringify(msg.IID));
                }
                if ((connections_admin != undefined) && (connections_admin.readyState == '1')) {
                    connections_admin.send(JSON.stringify({ class: 'server', type: 'jsondataR', data: msg.IID }));
                }
            }
            else if (msg.type == 'free_interaction') {
                if (connections_screen[msg.screen_id].readyState == '1') {
                    connections_screen[msg.screen_id].send(JSON.stringify(msg.data));
                }
                if ((connections_admin != undefined) && (connections_admin.readyState == '1')) {
                    connections_admin.send(JSON.stringify({ class: 'server', type: 'jsondataR', data: msg.data }));
                }
            }
            else if (msg.type == 'shot_camera') {
                connections_screen[msg.screen_id].send(JSON.stringify(msg.data));
                //console.log(msg.screen_id);
            }
        }
    }
    else if (msg.destination == 'mobile') {
        if (connections_mobile[msg.mobile_id] != undefined) {
            if (msg.type == 'msg_send') {
                if (connections_mobile[msg.mobile_id].readyState == '1') {
                    connections_mobile[msg.mobile_id].send(JSON.stringify(msg.data));
                }
                if ((connections_admin != undefined) && (connections_admin.readyState == '1')) {
                    connections_admin.send(JSON.stringify({ class: 'server', type: 'jsondataB', data: msg.data }));
                }
            }
            else if (msg.type == 'content_send') {
                connections_mobile[msg.mobile_id].send(JSON.stringify({ class: 'server', type: 'send_download_content', content_info: msg.data }));
                console.log("    Downloading the Content [ " + msg.data.ContentID + " ] --> " + "[ " + msg.mobile_id + " ]");
                console.log("#-----------------------------------------------------------------#\n");
                if ((connections_admin != undefined) && (connections_admin.readyState == '1')) {
                    connections_admin.send(JSON.stringify({ class: 'server', type: 'jsondataB', data: msg.data }));
                }
            }
        }
        else if (msg.type == 'current_camera_frame') {
            var file_buffer = new Buffer(msg.data, 'base64');
            camera_snapshot_buffer[msg.index] = 'accquired';
            msg.data = "temp";

            var new_object_id = msg.index;
            var current_file_name = "./camera_frames/" + new_object_id + ".jpg";
            fs.writeFileSync(current_file_name, file_buffer);
        }
    }
});

var HttpServer = http.createServer(function (request, response) {
    var peer_type;
    if (request.headers['user-agent']) {
        var ua = request.headers['user-agent'].toLowerCase();
        if (/lgtelecom/i.test(ua) || /Android/i.test(ua) || /blackberry/i.test(ua) || /iPhone/i.test(ua) || /iPad/i.test(ua) || /samsung/i.test(ua) || /symbian/i.test(ua) || /sony/i.test(ua) || /SCH-/i.test(ua) || /SPH-/i.test(ua) || /nokia/i.test(ua) || /bada/i.test(ua) || /semc/i.test(ua) || /IEMobile/i.test(ua) || /Mobile/i.test(ua) || /PPC/i.test(ua) || /Windows CE/i.test(ua) || /Windows Phone/i.test(ua) || /webOS/i.test(ua) || /Opera Mini/i.test(ua) || /Opera Mobi/i.test(ua) || /POLARIS/i.test(ua) || /SonyEricsson/i.test(ua) || /symbos/i.test(ua)) {
            peer_type = 'mobile';
            //console.log(request.headers);
        }
        else {
            peer_type = 'screen';
        }
    }
    
    var requested_url = request.url.split("/");
    //console.log(request.url + "      " + requested_url.length);
    if (requested_url.length == 2) {
        //Mobile & Screen 구별
        if (peer_type == 'mobile') {
            fs.readFile('./mobile/M_kitkat.html', { encoding: 'utf8' }, function (err, data) { // 인코딩 utf8로 얻어오고 저장도 동일하게 해야 한다.
                response.writeHead(200, { 'Content-Type': 'text/html' });
                while (1) {
                    if (data.indexOf('CONTENT_SERVER_ADDRESS') != -1) {
                        data = data.replace('CONTENT_SERVER_ADDRESS', network.getIP() + ":8099");
                        //console.log(network.getIP());
                    }
                    else
                        break;
                }
                response.end(data);
                //console.log("test2");
            });

        }
        else {
            if (requested_url[1] == 'admin') {
                fs.readFile('./admin/admin.html', function (err, data) {
                    response.writeHead(200, { 'Content-Type': 'text/html' });
                    response.end(data);
                });
            }
            else {
                if ( (1 <= requested_url[1]) && (requested_url[1] <= 4) ) {
                    var filename = './screen/screen_CP' + requested_url[1] + '.html';
                    //console.log(filename);
                    fs.readFile(filename, { encoding: 'utf8' }, function (err, data) { // 인코딩 utf8로 얻어오고 저장도 동일하게 해야 한다.
                        response.writeHead(200, { 'Content-Type': 'text/html' });
                        while (1) {
                            if (data.indexOf('CONTENT_SERVER_ADDRESS') != -1)
                                data = data.replace('CONTENT_SERVER_ADDRESS', network.getIP() + ":8099");
                            else
                                break;
                        }
                        while (1) {
                            if (data.indexOf('CP_SERVER_ADDRESS') != -1)
                                data = data.replace('CP_SERVER_ADDRESS', network.getIP());
                            else
                                break;
                        }
                        var split_html = data.split("</head>");
                        response.write(split_html[0]);
                        response.write("<link rel='stylesheet' type='text/css' href='http://" + network.getIP() + ":8099/css/contentpan_screen.css'>" +
                                       "<script src='./screen/js/ContentPan_functions_new.js'></script></head>");
                        for (var i = 1; i < split_html.length; i++) {
                            response.write(split_html[i]);
                        }
                        response.end();
                    });
                }
            }
        }
    }
    else if (requested_url.length == 3) {
        if (requested_url[2] == 'js') {
            fs.readFile("." + request.url, function (err, data) {
                response.writeHead(200, { 'Content-Type': 'text/javascript' });
                response.end(data);
            });
        }
        else if (requested_url[1] == 'camera_frames') {
            fs.readFile("." + request.url, function (err, data) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                response.end(data);
            });
        }
        else {
            fs.readFile("." + request.url, function (err, data) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                response.end(data);
            });
        }
    }
    else if (requested_url.length == 4) {
        if (requested_url[1] == 'camera') {
            if (connections_screen[requested_url[2]] != undefined) {
                var photo_index;
                var next_photo_index;
                var s_id = requested_url[2];
                var m_id = requested_url[3];
                photo_index = fs.readFileSync("./photo_index.txt", { encoding: 'utf8' });
                next_photo_index = photo_index;
                camera_snapshot_buffer['photo_' + photo_index] = "yet";
                connections_screen[requested_url[2]].send(JSON.stringify({ type: 'get_camera_frame', index: 'photo_'+photo_index }));
                fs.writeFileSync("photo_index.txt", ++next_photo_index);
                console.log("#-----------------------------------------------------------------#");
                console.log("    Taking a snapshot of [ " + s_id + " ] <-- " + "[ " + m_id + " ]");

                var interval_id = setInterval(function () {
                    if (camera_snapshot_buffer['photo_' + photo_index] == 'accquired') {
                        response.writeHead(200, { 'Content-Type': 'text/html' });
                        response.end("http://" + network.getIP() + "/camera_frames/" + "photo_" + photo_index + ".jpg");
                        console.log("    Downloading a snapshot of [ " + s_id + " ] --> " + "[ " + m_id + " ]");
                        console.log("#-----------------------------------------------------------------#\n");
                        delete camera_snapshot_buffer['photo_' + photo_index];
                        clearInterval(interval_id);
                    }
                }, 100, photo_index, s_id, m_id);
            }
        }
        else {
            fs.readFile("."+request.url, function (err, data) {
                response.writeHead(200, { 'Content-Type': 'text/javascript' });
                response.end(data);
            });
        }
    }
    else {
        //console.log(request.url);
        if(requested_url[2] == 'M_camera.html') {
            var filename = "./mobile/" + requested_url[2];
            //console.log(filename);
            fs.readFile(filename, { encoding: 'utf8' }, function (err, data) { // 인코딩 utf8로 얻어오고 저장도 동일하게 해야 한다.
                response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
                response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
                response.writeHead(200, { 'Content-Type': 'text/html' });
                while (1) {
                    if (data.indexOf('CONTENT_SERVER_ADDRESS') != -1)
                        data = data.replace('CONTENT_SERVER_ADDRESS', network.getIP() + ":8099");
                    else
                        break;
                }
                while (1) {
                    if (data.indexOf('CONTENTPAN_SCREEN_ID') != -1)
                        data = data.replace('CONTENTPAN_SCREEN_ID', 'CP_screen_id = "' + requested_url[3] +'"');
                    else
                        break;
                }
                while (1) {
                    if (data.indexOf('CONTENTPAN_MOBILE_ID') != -1)
                        data = data.replace('CONTENTPAN_MOBILE_ID', 'CP_mobile_id = "' + requested_url[4] + '"');
                    else
                        break;
                }
                response.end(data);
            });
        }
        else {
            console.log("unknown url");
        }
    }

}).listen(80);

var WebSocketServer = require('../ws').Server;
var wss = new WebSocketServer({ server: HttpServer });
var connections_screen = {};
var screen_mode = {};
var PING_MAX_ROUND_TRIP_TIME = 60000;
var PING_INTERVAL_TIME = 1000;//PING_MAX_ROUND_TRIP_TIME / 4;
var ping_req_screen = {};
var ping_delay_screen = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}];
var ping_delay_screen_max = -1;
var connections_mobile = {};
var ping_req_mobile = {};
var ping_delay_mobile = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}];
var ping_delay_mobile_max = -1;
var ping_max_count = 10;
var ping_counter = 0;
var mobile_id_counter = 0;
var timer_ping;
var the_number_of_mobiles = 0;
var connections_admin;


var fs = require('fs');
fs.readFile("mobileid.txt", function (err, data) {
    mobile_id_counter = data;
});

wss.on('connection', function (ws) {

    // Parse JSON Message
    ws.on('message', function (message, flags) {
        try {
            var json = JSON.parse(message);
            if (json.class == "screen") {
                if (json.type == "login") {
                    console.log("login: " + json.screen_id + "\n");
                    if (connections_screen[json.screen_id] != undefined) {
                        console.log("warning: redundant screen id");
                    }
                    ws.deviceType = 'screen';
                    ws.id = json.screen_id;
                    connections_screen[ws.id] = ws;
                    ws.send(JSON.stringify({ class: 'server', type: 'login_confirm', screen_id: json.screen_id }));
                    process.send({ class: 'child', type: 'screen_list', screen_list: Object.keys(connections_screen) });

                }
                else if (json.type == "ping_resp") {
                    ping_delay_screen[ping_counter][ws.id] = Date.now() - ping_req_screen[ws.id];
                    
                    screen_mode[ws.id] = json.mode;

                    if (connections_screen[ws.id].ping_timeout != undefined) {
                        clearTimeout(connections_screen[ws.id].ping_timeout);
                        //delete ws.ping_timeout;
                    }
                    var screenID = ws.id;
                    if (connections_screen[ws.id] != undefined) {
                        if (connections_screen[ws.id].readyState == '1') {
                            connections_screen[ws.id].ping_timeout = setTimeout(ping_timeout, PING_MAX_ROUND_TRIP_TIME, 'screen', screenID);
                        }
                    }
                }
                else if (json.type == "close") {
                    //console.log("close");
                }
                else {
                    process.send(json);
                }
            }
            else if (json.class == "mobile") {
                if (json.type == "login") {
                    //console.log("login_test");
                    if (json.mobile_id == "undefined") {
                        json.mobile_id = 'mobile' + (mobile_id_counter++);
                        fs.writeFileSync("mobileid.txt", mobile_id_counter);
                        the_number_of_mobiles++;
                    }
                    else {
                        if (connections_mobile[json.mobile_id] != undefined) {
                            console.log("warning: redundant mobile id");
                        }
                        else {
                            the_number_of_mobiles++;
                        }
                    }
                    ws.deviceType = 'mobile';
                    ws.id = json.mobile_id;
                    connections_mobile[ws.id] = ws;
                    //console.log("login_test");
                    ws.send(JSON.stringify({ class: 'server', type: 'login_confirm', mobile_id: json.mobile_id }));
                    process.send({ class: 'child', type: 'mobile_list', mobile_list: Object.keys(connections_mobile) });
                    ping_send();
                    console.log("login: " + json.mobile_id);
                    
                }
                else if (json.type == "ping_resp") {
                    ping_delay_mobile[ping_counter][ws.id] = Date.now() - ping_req_mobile[ws.id];
                    //console.log("id: " + ws.id + ", counter: " + ping_counter + ", time: " + Date.now());

                    if (connections_mobile[ws.id].ping_timeout != undefined) {
                        clearTimeout(connections_mobile[ws.id].ping_timeout);
                        //delete ws.ping_timeout; // delete 시에 다른 ping resp가 연달아 들어올 경우 clear 불가능한 ping timeout 발생
                    }
                    var mobileID = ws.id;
                    if (connections_mobile[ws.id] != undefined) {
                        if (connections_mobile[ws.id].readyState == '1') {
                            connections_mobile[ws.id].ping_timeout = setTimeout(ping_timeout, PING_MAX_ROUND_TRIP_TIME, 'mobile', mobileID);
                        }
                    }
                }
                else if (json.type == "close") {
                    //console.log("close");
                }
                else {
                    process.send(json);
                }
            }

            if (json.class == "admin") {
                var mobile_list = Object.keys(connections_mobile);
                var screen_list = Object.keys(connections_screen);
                
                process.send({ class: 'admin' });
                ws.send(JSON.stringify({
                    class: 'server', type: 'status',

                    mobiles: mobile_list,
                    ping_counter: ping_counter, mobile_pings: ping_delay_mobile, ping_screen_max: ping_delay_screen_max,

                    screens: screen_list,
                    screen_mode: screen_mode, screen_pings: ping_delay_screen, ping_mobile_max: ping_delay_mobile_max,

                    Interaction_ID_Priority: Interaction_ID_Priority, Interaction_ID_Group: Interaction_ID_Group, Interaction_Sensor_Group: Interaction_Sensor_Group,
                    screen_msg_transmitting_list: screen_msg_transmitted, mobile_msg_transmitting_list: mobile_msg_transmitted,
                    Manipulated_Sensor_Array: Manipulated_Sensor_Array
                }));
                ws.deviceType = 'admin';
                ws.id = 'admin';
                connections_admin = ws;
            }

            if ((connections_admin != undefined) && (connections_admin.readyState == '1')) {
                if ((json.type != 'ping_req') && (json.type != 'ping_resp') && (json.class != 'admin')) {
                    if(json.type == 'sensor_data')
                        connections_admin.send(JSON.stringify({ class: 'server', type: 'jsondataY', data: json }));
                    else
                        connections_admin.send(JSON.stringify({ class: 'server', type: 'jsondata', data: json }));
                }
            }
        } catch (e) {
            console.log('WebSocket Error:' + e.message);
        }

    });

    ws.onclose = function (e) { // 클라이언트에서 소켓을 닫으면..
        if (ws.deviceType == "screen") {
            console.log("screen WebSocket Closed [ ID: " + ws.id + ", CODE: " + e.code + " ]");
            if (connections_screen[ws.id] != undefined) {
                if (connections_screen[ws.id].readyState == '3') {
                    clearTimeout(connections_screen[ws.id].ping_timeout);
                    delete connections_screen[ws.id].ping_timeout;
                    connections_screen[ws.id].close();
                }
                delete connections_screen[ws.id];
                delete ping_req_screen[ws.id];
                for (var i = 0; i < ping_max_count; i++) {
                    delete ping_delay_screen[i][ws.id];
                }
                delete ws;
            }
            process.send({ class: 'child', type: 'screen_list', screen_list: Object.keys(connections_screen) });
            process.send({ class: 'child', type: 'connection_lost', dev_type: 'screen', dev_id: ws.id });
        }
        else if (ws.deviceType == "mobile") {
            console.log("mobile WebSocket Closed [ ID: " + ws.id + ", CODE: " + e.code + " ]");
            if (connections_mobile[ws.id] != undefined) {
                if (connections_mobile[ws.id].readyState == '3') {
                    clearTimeout(connections_mobile[ws.id].ping_timeout);
                    delete connections_mobile[ws.id].ping_timeout;
                    connections_mobile[ws.id].close();
                }
                delete connections_mobile[ws.id];
                delete ping_req_mobile[ws.id];
                for (var i = 0; i < ping_max_count; i++) {
                    delete ping_delay_mobile[i][ws.id];
                }
                delete ws;
                the_number_of_mobiles--;
            }
            process.send({ class: 'child', type: 'mobile_list', mobile_list: Object.keys(connections_mobile) });
            process.send({ class: 'child', type: 'connection_lost', dev_type: 'mobile', dev_id: ws.id });
            //console.log(the_number_of_mobiles);
        }
        else if (ws.deviceType == 'admin') {
            console.log("admin WebSocket Closed [ ID: " + ws.id + ", CODE: " + e.code + " ]");
            if (connections_admin.readyState == '3') {
                connections_admin.close();
            }
            delete connections_admin;
        }
    };

});

timer_ping = setInterval(ping_send, PING_INTERVAL_TIME);

function ping_send() {
    //var date = new Date(milliseconds);
    var array_screenid = Object.keys(connections_screen);
    for (id in connections_screen) {
        if (connections_screen[id].readyState == '1') {
            ping_req_screen[id] = Date.now();
            connections_screen[id].send(JSON.stringify({ class: 'server', type: 'ping_req', mode: the_number_of_mobiles}));

            ping_delay_screen_max = -1;
            for (var k = 0; k < ping_max_count; k++) {
                if (ping_delay_screen[k][id] != undefined) {
                    ping_delay_screen_max = Math.max(ping_delay_screen_max, ping_delay_screen[k][id]);
                }
            }
        }
    }
    var array_mobileid = Object.keys(connections_mobile);
    for (id in connections_mobile) {
        if (connections_mobile[id].readyState == '1') {
            ping_req_mobile[id] = Date.now();
            connections_mobile[id].send(JSON.stringify({ class: 'server', type: 'ping_req' }));
            //console.log("ping_send: " + id + ", " + Date.now());
            ping_delay_mobile_max = -1;
            for (var k = 0; k < ping_max_count; k++) {
                if (ping_delay_mobile[k][id] != undefined) {
                    ping_delay_mobile_max = Math.max(ping_delay_mobile_max, ping_delay_mobile[k][id]);
                }
            }
        }
    }
    ping_counter++;
    if (ping_counter == ping_max_count) {
        ping_counter = 0;
    }
    //console.log(ping_req_screen);
    //console.log(ping_delay_screen);
    //console.log(ping_req_mobile);
    //console.log(Object.keys(connections_screen));
    //console.log(Object.keys(connections_mobile));
    //console.log(the_number_of_mobiles);
}

function ping_timeout(deviceType, id) {
    console.log("Ping Timeout! connection closed : " + id + ", time: " + Date.now());
    if (deviceType == "screen") {
        //console.log("delay id: " + ws.id + " - " + ping_delay_screen[ws.id]);
        process.send({ class: 'child', type: 'connection_lost', dev_type: 'screen', dev_id: id });
        if (connections_screen[id] != undefined) {
            if (connections_screen[id].readyState == '1') {
                clearTimeout(connections_screen[id].ping_timeout);
                connections_screen[id].close();
            }
            delete connections_screen[id];
            delete ping_req_screen[id];
            for (var i = 0; i < ping_max_count; i++) {
                delete ping_delay_screen[i][id];
            }
        }
    }
    else if (deviceType == "mobile") {
        process.send({ class: 'child', type: 'connection_lost', dev_type: 'mobile', dev_id: id });
        if (connections_mobile[id] != undefined) {
            console.log(connections_mobile[id].readyState);
            if (connections_mobile[id].readyState == '1') {
                clearTimeout(connections_mobile[id].ping_timeout);
                connections_mobile[id].close();
            }
            delete connections_mobile[id];
            delete ping_req_mobile[id];
            the_number_of_mobiles--;
            for (var i = 0; i < ping_max_count; i++) {
                delete ping_delay_mobile[i][id];
            }
        }
    }
}