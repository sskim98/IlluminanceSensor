this.ASSIGN_INTERACTION_ID = "assign_Interaction_ID";
this.FREE_INTERACTION_ID = "free_Interaction_ID";
this.GET_DIGITAL_SIGNAGE_CONTENTS = "get_Digital_Signage_Contents";
this.GET_MOBILE_ID = "get_Mobile_ID";
this.GET_BRIGHTNESS = "get_Brightness";
this.GET_MOBILE_CONTENTS = "get_Mobile_Contents";
this.SET_DIGITAL_SIGNAGE_LOCATION = "set_Digital_Signage_Location";
this.SET_MOBILE_LOCATION = "set_Mobile_Location";
this.DELETE_DIGITAL_SIGNAGE_LOCATION = "delete_Digital_Signage_Location";
this.DELETE_MOBILE_LOCATION = "delete_Mobile_Location";
this.IS_MOBILE_IN_CLUSTER = "is_Mobile_in_Cluster";
this.GET_MOBILES_IN_CLUSTER = "get_Mobiles_in_Cluster";
this.GET_INTERACTION_SCREEN_ID = "get_Interaction_Screen_ID";
this.GET_INTERACTION_CONTENT_ID = "get_Interaction_Content_ID";
this.GET_INTERACTION_STEP = "get_Interaction_Step";
this.GET_INTERACTION_LENGTH = "get_Interaction_Length";
this.SET_SENSOR_DATA = "set_Sensor_Data";
this.SET_SENSOR_ARRAY = "set_Sensor_Array";
this.CLEAR_SENSOR_DATA_COUNT = "clear_Sensor_Data_Count";
this.GET_SENSOR_DATA_COUNT = "get_Sensor_Data_Count";
this.GET_THE_NUM_OF_MOBILES = "get_the_Num_of_Mobiles";
this.GET_INTERACTION_TYPE = "get_Interaction_type";
this.GET_COUPLED_MOBILES = "get_Coupled_Mobiles";
this.GET_DOWNLOAD_CONTENT = "get_Download_Content";
this.GET_UPLOAD_CONTENT = "get_Upload_Content";
this.GET_CONTROL_CONTENT = "get_Control_Content";
this.PRINT = "print"
this.GET_INTERACTION_ID_GROUP = "get_Interaction_ID_Group";
this.GET_INTERACTION_SENSOR_GROUP = "get_Interaction_Sensor_Group";
this.GET_INTERACTION_SENSOR_GROUP_ELEMENT = "get_Interaction_Sensor_Group_Element";
this.GET_INTERACTION_ID_PRIORITY = "get_Interaction_ID_Priority";
this.SET_MOBILE_STEP = "set_mobile_step";
this.IS_ASSIGNED_IID = "is_assigned_IID";

var THRESHOLD_WEIGHT = 0.20; //min: 0.05, max: 0.45 // light_sensor ��� ���� Ŭ���� ���� ���� �����ϱ� �����

Content = {
    content1: { ContentID: 'content1', src: 'http://itc.kaist.ac.kr/~sskim98/ad_3.webm', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/ad_3.webm', Content_Left: '2', Content_Top: '2', Content_Width: '30', Content_Height: '30', Content_Type: 'video', Interaction_Type: 'download' },
    content2: { ContentID: 'content2', src: 'http://itc.kaist.ac.kr/~sskim98/ad_4.webm', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/ad_4.webm', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'video', Interaction_Type: 'download' },
    p01: { ContentID: 'p01', src: 'http://itc.kaist.ac.kr/~sskim98/p01.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p01.png', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'download' },
    p02: { ContentID: 'p02', src: 'http://itc.kaist.ac.kr/~sskim98/p02.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p02.png', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'download' },
    p03: { ContentID: 'p03', src: 'http://itc.kaist.ac.kr/~sskim98/p03.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p03.png', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'download' },
    p04: { ContentID: 'p04', src: 'http://itc.kaist.ac.kr/~sskim98/p04.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p04.png', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'download' },
    p05: { ContentID: 'p05', src: 'http://itc.kaist.ac.kr/~sskim98/p05.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p05.png', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'download' },
    p06: { ContentID: 'p06', src: 'http://itc.kaist.ac.kr/~sskim98/p06.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p06.png', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'download' },
    p07: { ContentID: 'p07', src: 'http://itc.kaist.ac.kr/~sskim98/p07.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/test06.html', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'link' },
    p08: { ContentID: 'p08', src: 'http://itc.kaist.ac.kr/~sskim98/p08.png', Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p08.png', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'upload' },
    p09: { ContentID: 'p09', src: 'http://itc.kaist.ac.kr/~sskim98/p09.jpg', Content_Left: '1', Content_Top: '52', Content_Width: '30', Content_Height: '30', Content_Type: 'image', Interaction_Type: 'download' }
}

Interaction_ID_Group = {
    //    '01': { index: '0', used: false, id: '01', length: '2', brightness: ['0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '10': { index: '1', used: false, id: '10', length: '2', brightness: ['1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '010': { index: '0', used: false, id: '010', length: '3', brightness: ['0', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '101': { index: '1', used: false, id: '101', length: '3', brightness: ['1', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '001': { index: '2', used: false, id: '001', length: '3', brightness: ['0', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '100': { index: '3', used: false, id: '100', length: '3', brightness: ['1', '0', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '011': { index: '4', used: false, id: '011', length: '3', brightness: ['0', '1', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '110': { index: '5', used: false, id: '110', length: '3', brightness: ['1', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '1010': { index: '0', used: false, id: '1010', length: '4', brightness: ['1', '0', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '1101': { index: '1', used: false, id: '1101', length: '4', brightness: ['1', '1', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '1001': { index: '2', used: false, id: '1001', length: '4', brightness: ['1', '0', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '0110': { index: '3', used: false, id: '0110', length: '4', brightness: ['0', '1', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '0101': { index: '4', used: false, id: '0101', length: '4', brightness: ['0', '1', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '1011': { index: '5', used: false, id: '1011', length: '4', brightness: ['1', '0', '1', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '0100': { index: '6', used: false, id: '0100', length: '4', brightness: ['0', '1', '0', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    '0010': { index: '7', used: false, id: '0010', length: '4', brightness: ['0', '0', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '0001': { index: '14', used: false, id: '0001', length: '4', brightness: ['0', '0', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '0011': { index: '15', used: false, id: '0011', length: '4', brightness: ['0', '0', '1', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '0111': { index: '16', used: false, id: '0111', length: '4', brightness: ['0', '1', '1', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '1000': { index: '17', used: false, id: '1000', length: '4', brightness: ['1', '0', '0', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '1100': { index: '18', used: false, id: '1100', length: '4', brightness: ['1', '1', '0', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //    '1110': { index: '19', used: false, id: '1110', length: '4', brightness: ['1', '1', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' }
    //-2-'10101': { index: '0', used: false, id: '10101', length: '5', brightness: ['1', '0', '1', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'01101': { index: '1', used: false, id: '01101', length: '5', brightness: ['0', '1', '1', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'00101': { index: '2', used: false, id: '00101', length: '5', brightness: ['0', '0', '1', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'10010': { index: '3', used: false, id: '10010', length: '5', brightness: ['1', '0', '0', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'01001': { index: '4', used: false, id: '01001', length: '5', brightness: ['0', '1', '0', '0', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'11010': { index: '5', used: false, id: '11010', length: '5', brightness: ['1', '1', '0', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'10110': { index: '6', used: false, id: '10110', length: '5', brightness: ['1', '0', '1', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'10100': { index: '7', used: false, id: '10100', length: '5', brightness: ['1', '0', '1', '0', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'01010': { index: '8', used: false, id: '01010', length: '5', brightness: ['0', '1', '0', '1', '0'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
    //-2-'01011': { index: '9', used: false, id: '01011', length: '5', brightness: ['0', '1', '0', '1', '1'], gathering: 'no', step: '0', m_step: '0', screen_id: '', content_id: '', mobile_content: '', i_type: '', target: '', sensors: [], assign_time: '' },
};

Interaction_Sensor_Group = [
//    ['0', '0'], // id: 01
//    ['0', '0'], // id: 10
//    ['0', '0', '0'], // id: 010
//    ['0', '0', '0'], // id: 101
//    ['0', '0', '0'], // id: 001
//    ['0', '0', '0'], // id: 100
//    ['0', '0', '0'], // id: 011
//    ['0', '0', '0'], // id: 110
    ['0', '0', '0', '0'], // id: 1010
    ['0', '0', '0', '0'], // id: 1101
    ['0', '0', '0', '0'], // id: 1001
    ['0', '0', '0', '0'], // id: 0110
    ['0', '0', '0', '0'], // id: 0101
    ['0', '0', '0', '0'], // id: 1011
    ['0', '0', '0', '0'], // id: 0100
    ['0', '0', '0', '0']//, // id: 0010
//    ['0', '0', '0', '0'], // id: 0001
//    ['0', '0', '0', '0'], // id: 0011
//    ['0', '0', '0', '0'], // id: 0111
//    ['0', '0', '0', '0'], // id: 1000
//    ['0', '0', '0', '0'], // id: 1100
//    ['0', '0', '0', '0'] // id: 1110
//-2-    ['0', '0', '0', '0', '0'], // id: 01010
//-2-    ['0', '0', '0', '0', '0'], // id: 11010
//-2-    ['0', '0', '0', '0', '0'], // id: 10010
//-2-    ['0', '0', '0', '0', '0'], // id: 10110
//-2-    ['0', '0', '0', '0', '0'], // id: 01101
//-2-    ['0', '0', '0', '0', '0'], // id: 00101
//-2-    ['0', '0', '0', '0', '0'], // id: 01011
//-2-    ['0', '0', '0', '0', '0'], // id: 01001
//-2-    ['0', '0', '0', '0', '0'], // id: 10101
//-2-    ['0', '0', '0', '0', '0']  // id: 10100
];

//Interaction_ID_Priority = ['01', '10', '010', '101', '001', '100', '011', '110', '1010', '1101', '1001', '0110', '0101', '1011', '0100', '0010', '0001', '0011', '0111', '1000', '1100', '1110'];
//Interaction_ID_Priority = ['010', '101', '001', '100', '011', '110', '1010', '1101', '1001', '0110', '0101', '1011', '0100', '0010', '0001', '0011', '0111', '1000', '1100', '1110'];
Interaction_ID_Priority = ['1010', '1101', '1001', '0110', '0101', '1011', '0100', '0010'];
//-2-Interaction_ID_Priority = ['10101', '01101', '00101', '10010', '01001', '11010', '10110', '10100', '01010', '01011'];
cluster = {};   //{ screen_id: {s_latitude: '', s_longitude: '', mobiles: {mobile_id1, mobile_id2, ... } }
outsider = { }; //mobile0: { status: 'faraway', threshold: 50} };
this.clustering = function (operation, id, latitude, longitude, status) {
    if (operation == "set_Digital_Signage_Location") {
        cluster[id] = { s_latitude: '', s_longitude: '', mobiles: {} };
        cluster[id].s_latitude = parseInt(latitude);
        cluster[id].s_longitude = parseInt(longitude);
        //console.log(cluster);
    }
    else if (operation == "set_Mobile_Location") {
        //console.log("mobileID     " + id+ " - " + status + "lat: " + latitude);
        for (screenid in cluster) {
            //latitude = parseInt(latitude);
            //longitude = parseInt(longitude);

            if (latitude != 'undefined') {
                cluster[screenid].mobiles[id] = {};
                cluster[screenid].mobiles[id]['status'] = status;
                //console.log("cluster[screenid].mobiles: ");
                //console.log(cluster[screenid].mobiles);
                if (status == 'pending') {
                    delete cluster[screenid].mobiles[id];
                    console.log("PENDING");
                }
            }

        }
        //console.log(cluster);
        //console.log("latitude " + latitude + "longitude" + longitude);
    }
    else if (operation == "delete_Digital_Signage_Location") {
        delete cluster[id];
        //console.log("cluster id=" + id + " is deleted");
        //console.log(cluster);
    }
    else if (operation == "delete_Mobile_Location") {
        for (screenid in cluster) {
            delete cluster[screenid].mobiles[id];
            //console.log(cluster);
        }
    }
    else if (operation == "is_Mobile_in_Cluster") {
        //console.log(cluster);
        if (Object.keys(cluster[id].mobiles).length > 0) {
            return true;
        }
        else {
            return false;
        }

    }
    else if (operation == "get_Mobiles_in_Cluster") {
        if ((cluster == 'undefined') || (cluster == null)) {
            console.log("undefined or null cluster: id= " + id);
            return null;
        }
        else if ((cluster[id] == 'undefined') || (cluster[id] == null)) {
            console.log("undefined or null cluster[id]: id= " + id);
            return null;
        }
        else if ((cluster[id].mobiles == 'undefined') || (cluster[id].mobiles == null)) {
            console.log("cluster[id].mobiles is undefined or null:   id= " + id);
        }
        else {
            return cluster[id].mobiles;
        }
    }
    else {
        console.log("Invalid oparation code in clustering");
    }
}

var mobile_id_counter = 0;
var screen_id_counter = 0;
var permission = 1;
var fs = require('fs');
var fs2 = require('fs');

fs.readFile("mobileid.txt", function (err, data) {
    mobile_id_counter = data;
});
fs2.readFile("screenid.txt", function (err, data) {
    screen_id_counter = data;
});


this.access = function (operation, key) {

    if (operation == "assign_Interaction_ID") {
        var interaction_info = get_new_interactionID(key);
        if (interaction_info == 'unable_to_assign_ID') {
            //console.log("unassigned");
            return { class: 'server', type: 'interaction_ID', status: 'unassigned', value: interaction_info };
        }
        else {
            return { class: 'server', type: 'interaction_ID', status: 'assigned', value: interaction_info };
        }
    }
    else if (operation == "free_Interaction_ID") {
        Interaction_ID_Group[key].used = false;
        Interaction_ID_Group[key].gathering = 'no';
        Interaction_ID_Group[key].step = '0';
        Interaction_ID_Group[key].target = '';
    }
    else if (operation == "get_Digital_Signage_Contents") {
        var screenID;
        if (key == 'unassigned') {
            console.log("screen ID assignment");
            screenID = 'screen' + (screen_id_counter++);
            fs2.writeFileSync("screenid.txt", screen_id_counter);
        }
        else
            screenID = key;

        var screenData = 
            { class: 'server', type: 'screenData', screen_id: screenID,
                page:
                [ 
                /*    {contents: [{   ContentID: 'content1', src: 'http://itc.kaist.ac.kr/~sskim98/ad_3.webm',
                                    Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/ad_3.webm',
                                    Content_Left: '1', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                    Content_Type: 'video', Interaction_Type: 'download'
                                },
                                {
                                    ContentID: 'content2', src: 'http://itc.kaist.ac.kr/~sskim98/ad_4.webm',
                                    Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/ad_4.webm',
                                    Content_Left: '51', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                    Content_Type: 'video', Interaction_Type: 'download'
                                },
                                {
                                    ContentID: 'p03', src: 'http://itc.kaist.ac.kr/~sskim98/p03.png',
                                    Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p03.png',
                                    Content_Left: '1', Content_Top: '52', Content_Width: '48', Content_Height: '48',
                                    Content_Type: 'image', Interaction_Type: 'download'
                                },
                                 {
                                     ContentID: 'p09', src: 'http://itc.kaist.ac.kr/~sskim98/p09.jpg',
                                     Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p09.jpg',
                                     Content_Left: '51', Content_Top: '52', Content_Width: '48', Content_Height: '48',
                                     Content_Type: 'image', Interaction_Type: 'download'
                                 }]
                    },
                    { contents: [{  ContentID: 'p01', src: 'http://itc.kaist.ac.kr/~sskim98/p01.png',
                                    Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p01.png',
                                    Content_Left: '1', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                    Content_Type: 'image', Interaction_Type: 'download'
                                 },
                                 {  ContentID: 'p04', src: 'http://itc.kaist.ac.kr/~sskim98/p04.png',
                                    Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p04.png',
                                    Content_Left: '51', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                    Content_Type: 'image', Interaction_Type: 'download'
                                 }]
                    },
                    { contents: [{  ContentID: 'p05', src: 'http://itc.kaist.ac.kr/~sskim98/p05.png',
                                    Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p05.png',
                                    Content_Left: '1', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                    Content_Type: 'image', Interaction_Type: 'download'
                                 },
                                 {
                                     ContentID: 'p06', src: 'http://itc.kaist.ac.kr/~sskim98/p06.png',
                                     Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p06.png',
                                     Content_Left: '51', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                     Content_Type: 'image', Interaction_Type: 'download'
                                 }]
                    },
                    { contents: [{  ContentID: 'p07', src: 'http://itc.kaist.ac.kr/~sskim98/p07.png',
                                    Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/test06.html',
                                    Content_Left: '1', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                    Content_Type: 'image', Interaction_Type: 'link'
                                 },
                                 {
                                     ContentID: 'p08', src: 'http://itc.kaist.ac.kr/~sskim98/p08.png',
                                     Mobile_src: 'http://itc.kaist.ac.kr/~sskim98/p08.png',
                                     Content_Left: '51', Content_Top: '2', Content_Width: '48', Content_Height: '48',
                                     Content_Type: 'image', Interaction_Type: 'upload'
                                 }]
                    }
                    */
                ]
            };
        return screenData;
    }
    else if (operation == "get_Brightness") {
        /*
        if (Interaction_ID_Group[key].step >= Interaction_ID_Group[key].length) {
            //console.log('over step = ' + Interaction_ID_Group[key].step);
            Interaction_ID_Group[key].step = '0';
        }
        */
        Interaction_ID_Group[key].gathering = 'yes';
        var action = key.charAt(Interaction_ID_Group[key].step++);
        //console.log("Get Brightness = " + action);
        if (action == '1')
            return { class: 'server', type: 'change_brightness', interaction_id: key, action: 'increase' };
        else if (action == '0')
            return { class: 'server', type: 'change_brightness', interaction_id: key, action: 'decrease' };
        else {
            console.log('Interaction step data is undefined');
            console.log("action : " + action);
            console.log("key : " + key);
            console.log("Interaction_ID_Group[key] : ");
            console.log(Interaction_ID_Group[key]);
        }
    }
    else if (operation == "set_mobile_step") {
        Interaction_ID_Group[key].m_step++;
        //console.log("Get Brightness = " + action);
        if (Interaction_ID_Group[key].m_step >= Interaction_ID_Group[key].length) {
            Interaction_ID_Group[key].m_step = '0';
            //this.access(this.FREE_INTERACTION_ID, key);
            return { class: 'server', i_type: Interaction_ID_Group[key].i_type, content_id: Interaction_ID_Group[key].content_id, mobile_content: Interaction_ID_Group[key].mobile_content };
        }
        return false;
    }
    else if (operation == "get_Mobile_Contents") {
        var mobileID;
        if (key == 'unassigned') {
            console.log("mobile ID assignment");
            mobileID = 'mobile' + (mobile_id_counter++);
            fs.writeFileSync("mobileid.txt", mobile_id_counter );
        }
        else
            mobileID = key;

        var mobileData = {
            class: 'server', type: 'mobileData', mobile_id: mobileID,
            contents: []
        };

        
        return mobileData;
    }
    else if (operation == "get_Interaction_Screen_ID") {
        return Interaction_ID_Group[key].screen_id;
    }
    else if (operation == "get_Interaction_Content_ID") {
        return Interaction_ID_Group[key].content_id;
    }
    else if (operation == "get_Interaction_Step") {
        return Interaction_ID_Group[key].step - 1;
    }
    else if (operation == "get_Interaction_Length") {
        return Interaction_ID_Group[key].length;
    }
    else if (operation == "set_Sensor_Data") {
        if (Interaction_ID_Group[key.interaction_id].used == true) {
            if (Interaction_ID_Group[key.interaction_id].sensors[key.mobile_id] != 'undefined') {
                Interaction_ID_Group[key.interaction_id].sensors[key.mobile_id][key.step] = key.sensor_data;
                Interaction_ID_Group[key.interaction_id].sensors.sensor_data_count++;
                //console.log(Interaction_ID_Group[key.interaction_id].sensors);
                return true;
            }
        }
    }
    else if (operation == "set_Sensor_Array") {
        //console.log(key.data);
        for (id in Interaction_ID_Group) {
            if (Interaction_ID_Group[id].index == key.index) {
                Interaction_Sensor_Group[key.index][Interaction_ID_Group[id].m_step] = key.data;
                break;
            }
        }
    }
    else if (operation == "clear_Sensor_Data_Count") {
        Interaction_ID_Group[key].sensors.sensor_data_count = 0;
    }
    else if (operation == "get_Sensor_Data_Count") {
        return Interaction_ID_Group[key].sensors.sensor_data_count;
    }
    else if (operation == "get_the_Num_of_Mobiles") {
        return Object.keys(Interaction_ID_Group[key].target).length;
    }
    else if (operation == "get_Interaction_type") {
        //console.log(Interaction_ID_Group[key]);
        return Interaction_ID_Group[key].i_type;
    }
    else if (operation == "get_Coupled_Mobiles") {
        
        //console.log(Interaction_ID_Group[key].sensors);
        //console.log(Interaction_ID_Group[key].target);
        var coupled_mobile = [];
        for (mobile_id in Interaction_ID_Group[key].target) {
            //var threshold = Interaction_ID_Group[key].target[mobile_id].threshold;
            var high_th = 0;
            for (element in Interaction_ID_Group[key].sensors[mobile_id]) {
                if (high_th < Interaction_ID_Group[key].sensors[mobile_id][element]) {
                    high_th = Interaction_ID_Group[key].sensors[mobile_id][element]
                }
            }
            var low_th = 1000;
            for (element in Interaction_ID_Group[key].sensors[mobile_id]) {
                if (low_th > Interaction_ID_Group[key].sensors[mobile_id][element]) {
                    low_th = Interaction_ID_Group[key].sensors[mobile_id][element]
                }
            }
            var threshold = (high_th + low_th) / 2;
            var is_match = true;

            for (var i = 0; i < Interaction_ID_Group[key].id.length; i++) {
                var data = Interaction_ID_Group[key].sensors[mobile_id][i];
                if (data == 'undefined') {
                    is_match = false;
                }
                else {
                    //console.log("data -> " + data);
                    if (data <= threshold * (1 - THRESHOLD_WEIGHT)) {
                        if (key.charAt(i) != '0') {
                            is_match = false;
                        }
                    }
                    else if (data >= threshold * (1 + THRESHOLD_WEIGHT)) {
                        if (key.charAt(i) != '1') {
                            is_match = false;
                        }
                    }
                    else {
                        is_match = false;
                    }
                }
            }
            if (is_match == true) {
                //console.log("Match : " + mobile_id + " interaction_id : " + key);
                coupled_mobile.push(mobile_id);
            }
        }

        return coupled_mobile;
    }
    else if (operation == "get_Download_Content") {
        //console.log(Interaction_ID_Group[key].mobile_content);
        return Interaction_ID_Group[key].mobile_content;
    }
    else if (operation == "get_Upload_Content") {
        return Content[key];
    }
    else if (operation == "get_Control_Content") {
        return Content[key];
    }
    else if (operation == 'print') {
        console.log(cluster);
        console.log(Interaction_ID_Group);
    }
    else if (operation == 'get_Interaction_ID_Group') {
        return Interaction_ID_Group;
    }
    else if (operation == 'get_Interaction_Sensor_Group') {
        return Interaction_Sensor_Group;
    }
    else if (operation == 'get_Interaction_Sensor_Group_Element') {
        return Interaction_Sensor_Group[key];
    }
    else if (operation == 'get_Interaction_ID_Priority') {
        return Interaction_ID_Priority;
    }
    else if (operation == 'is_assigned_IID') {
        for (var i = 0; i < Interaction_ID_Priority.length; i++) {
            if (Interaction_ID_Group[Interaction_ID_Priority[i]].used == true) {
                return true;
            }
        }
        return false;
    }
    else
        console.log("Undefined DB operation: " + operation);
}

get_new_interactionID = function (target) {
    for (var i = 0; i < Interaction_ID_Priority.length; i++) { // ��ü IID_Group����
        if (Interaction_ID_Group[Interaction_ID_Priority[i]].used == false) { // ������ �ʴ� ID�� ã�Ƽ�
            var candidate_ID = Interaction_ID_Group[Interaction_ID_Priority[i]];
            var can_use_candidate_ID = 'yes';
            for (var j = 0; j < Interaction_ID_Priority.length; j++) { // ��ü IID_Group���� �� ���Ǵ� �͵� �� ��
                if (Interaction_ID_Group[Interaction_ID_Priority[j]].used == true) { // ���Ǵ� ID��
                    var assigned_ID = Interaction_ID_Group[Interaction_ID_Priority[j]];
                    if (assigned_ID.step < assigned_ID.length) {                    // step�� ���� ������ �ʾҰ�
                        var is_code_overlapped = true;
                        for (var k = 0; k < assigned_ID.length - assigned_ID.step; k++) { // ��� step�� ������ ��
                            if (k < candidate_ID.length) {
                                if (assigned_ID.brightness[assigned_ID.step + k] != candidate_ID.brightness[k]) { // ���� step�� candidate�� ù ��Ʈ�� ������ �浹 ���ɼ� ����
                                    is_code_overlapped = false;
                                }
                            }
                        }
                        if (is_code_overlapped == true) {
                            can_use_candidate_ID = 'no';
                            break;
                        }
                    }
                }
            }
            if (can_use_candidate_ID == 'yes') {
                candidate_ID.used = true;
                candidate_ID.gathering = 'no';
                candidate_ID.step = '0';
                candidate_ID.m_step = '0';
                candidate_ID.screen_id = target.screen_id;
                candidate_ID.content_id = target.content_id;
                candidate_ID.mobile_content = target.mobile_content;
                candidate_ID.i_type = target.mobile_content.Interaction_Type;
                candidate_ID.target = '';
                candidate_ID.sensors = '';
                candidate_ID.assign_time = Date.now();
                return candidate_ID;
            }
        }
    }

    return 'unable_to_assign_ID';
}
/*
get_new_interactionID = function (target) {
    for (var i = 0; i < Interaction_ID_Priority.length; i++) {
        if (Interaction_ID_Group[Interaction_ID_Priority[i]].used == false) {
            Interaction_ID_Group[Interaction_ID_Priority[i]].used = true;
            Interaction_ID_Group[Interaction_ID_Priority[i]].gathering = 'no';
            Interaction_ID_Group[Interaction_ID_Priority[i]].step = '0';
            Interaction_ID_Group[Interaction_ID_Priority[i]].m_step = '0';
            Interaction_ID_Group[Interaction_ID_Priority[i]].screen_id = target.screen_id;
            Interaction_ID_Group[Interaction_ID_Priority[i]].content_id = target.content_id;
            Interaction_ID_Group[Interaction_ID_Priority[i]].mobile_content = target.mobile_content;
            Interaction_ID_Group[Interaction_ID_Priority[i]].i_type = target.mobile_content.Interaction_Type;
            Interaction_ID_Group[Interaction_ID_Priority[i]].target = '';
            Interaction_ID_Group[Interaction_ID_Priority[i]].sensors = '';
            Interaction_ID_Group[Interaction_ID_Priority[i]].assign_time = Date.now();
            return this.Interaction_ID_Group[this.Interaction_ID_Priority[i]];
        }
    }
    
    return 'unable_to_assign_ID';
}
*/

this.view_internal_variables = function () {
    console.log("CP_Server.js");
    console.log("----------------------------------------------------------------------------");
    console.log("==  Interaction_ID_Group ==");
    console.log(Interaction_ID_Group);
    console.log("----------------------------------------------------------------------------");
    console.log("==  Interaction_Sensor_Group ==");
    console.log(Interaction_Sensor_Group);
    console.log("----------------------------------------------------------------------------");
    console.log("==  is_IID_Group_changed ==");
    if (typeof is_IID_Group_changed != 'undefined') {
        console.log(is_IID_Group_changed);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  is_ongoing_msg_exchange ==");
    if (typeof is_ongoing_msg_exchange != 'undefined') {
        console.log(is_ongoing_msg_exchange);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  interaction_step_status ==");
    if (typeof interaction_step_status != 'undefined') {
        console.log(interaction_step_status);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  screen_list ==");
    if (typeof screen_list != 'undefined') {
        console.log(screen_list);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  mobile_list ==");
    if (typeof mobile_list != 'undefined') {
        console.log(mobile_list);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  screen_msg_transmitted ==");
    if (typeof screen_msg_transmitted != 'undefined') {
        console.log(screen_msg_transmitted);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  screen_msg_gathering ==");
    if (typeof screen_msg_gathering != 'undefined') {
        console.log(screen_msg_gathering);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  mobile_msg_transmitted ==");
    if (typeof mobile_msg_transmitted != 'undefined') {
        console.log(mobile_msg_transmitted);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  mobile_msg_gathering ==");
    if (typeof mobile_msg_gathering != 'undefined') {
        console.log(mobile_msg_gathering);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  mobile_sensor_data_gathered ==");
    if (typeof mobile_sensor_data_gathered != 'undefined') {
        console.log(mobile_sensor_data_gathered);
    }
    console.log("----------------------------------------------------------------------------");
    console.log("==  mobile_sensor_data_gathered_array ==");
    if (typeof mobile_sensor_data_gathered_array != 'undefined') {
        console.log(mobile_sensor_data_gathered_array);
    }
    console.log("----------------------------------------------------------------------------");
}