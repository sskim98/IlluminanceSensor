var ws;
var screenID;
var s_latitude;
var s_longitude;
var timer_heartbeat;
var timer_reload;
var ongoing_interaction = {};
var HEARTBEAT_CYCLE = '500';
var RELOAD_CYCLE = '500';
var TAP_HOLD_DELAY = '250';
var touch_enable = true;
var ContentPan_Operation_mode = 'set_CP_Single_Mode';
var websocketAddress = 'ws://' + location.host;

$(document).ready(function () {

    ws = new window.WebSocket(websocketAddress);
    ws.binaryType = 'blob';

    ws.onopen = function (e) {
        screenID = "admin";
        s_latitude = "";
        s_longitude = "";
        setTimeout(function () {
            ws.send(JSON.stringify({ class: 'screen', type: 'login', screen_id: screenID, latitude: s_latitude, longitude: s_longitude }));
        }, 100);
        
    }

    ws.onmessage = function (e) {
        var json = JSON.parse(e.data);

        if (json.type == 'redundant_id') {
            //alert("���� ������ ���������� ������� �ʾҽ��ϴ�. ���ΰ�ħ ���ּ���");
            window.location.reload();
        }
        else if (json.type == 'screenData') {
            $(".content_frame").each(function () {
                draw_alphalayer(this);
            });
            timer_heartbeat = setInterval(heartbeat, HEARTBEAT_CYCLE);
        }
        else if (json.type == 'set_CP_Coupling_Mode') {
            //alert(json.type);
            if (ContentPan_Operation_mode != json.type) {
                $('.alphalayer').css("border", "3px");
                $('.alphalayer').css("border-color", "red");
                $('.alphalayer').css("border-style", "dotted");
                $('.alphalayer').css("width", "99.5%");
                $('.alphalayer').css("height", "99%");
                $('.alphalayer').css("line-height", "99%");
                ContentPan_Operation_mode = json.type;
                
            }
        }
        else if (json.type == 'set_CP_Single_Mode') {
            //alert(ContentPan_Operation_mode);
            if (ContentPan_Operation_mode != json.type) {
                $('.alphalayer').css("border", "0px");
                $('.alphalayer').css("border-color", "red");
                $('.alphalayer').css("border-style", "dotted");
                $('.alphalayer').css("width", "100%");
                $('.alphalayer').css("height", "100%");
                $('.alphalayer').css("line-height", "100%");
                ContentPan_Operation_mode = json.type;
            }
        }
        else if (json.type == 'interaction_ID') {
            if (json.status == 'unassigned') {
                alert("���� ������ ���� �ʹ� �����ϴ�.");
            }
            else {
                if (ongoing_interaction[json.value.content_id].interaction_content == json.value.content_id) {
                    ongoing_interaction[json.value.content_id].interaction_ID = json.value.id;
                    //console.log('interaction ID assigned : ' + json.value.content_id);
                    ws.send(JSON.stringify({ class: 'screen', type: 'Interaction_Start', interaction_id: ongoing_interaction[json.value.content_id].interaction_ID }));
                }
            }
        }
        else if (json.type == 'change_brightness') {
            for (key in ongoing_interaction) {
                if (ongoing_interaction[key].interaction_ID == json.interaction_id) {
                    //console.log(ongoing_interaction[key]);
                    $($('#' + ongoing_interaction[key].interaction_content).children()[0]).css("opacity", "0.2");
                    if (json.action == 'increase') {
                        $('#' + ongoing_interaction[key].interaction_content).css("background-color", "white");
                    }
                    else if (json.action == 'decrease') {
                        $('#' + ongoing_interaction[key].interaction_content).css("background-color", "black");
                    }
                    json.class = 'screen'; json.type = 'brightness_is_set'; json.action = 'done';
                    ws.send(JSON.stringify(json));
                }
            }
        }
        else if (json.type == 'free_interaction') {
            for (key in ongoing_interaction) {
                if (ongoing_interaction[key].interaction_ID == json.interaction_id) {
                    $($('#' + ongoing_interaction[key].interaction_content).children()[0]).css("opacity", "1");
                    $('#' + ongoing_interaction[key].interaction_content).css("background-color", "rgba(0,0,0,0)");
                    delete ongoing_interaction[key];
                }
            }
        }
        else if (json.type == 'upload_content') {
            $(".alphalayer").each(function () {
                console.log("json.content_id : " + json.target_content_id);
                if (this.getAttribute("data-ContentID") == json.target_content_id) {
                    if (json.upload_content_info.Content_Type == 'VIDEO') {
                        var content = document.createElement("VIDEO");
                        $(content).addClass("upload_content");
                        content.setAttribute('controls', '');
                        content.setAttribute('loop', '');
                        content.setAttribute('preload', 'auto');
                        content.setAttribute('autoplay', 'autoplay');
                        content.setAttribute('type', 'video/webm');

                        content.setAttribute('src', json.upload_content_info.src);
                        content.play();
                    }
                    else if (json.upload_content_info.Content_Type == 'IMG') {
                        var content = document.createElement("IMG");
                        $(content).addClass("upload_content");
                        content.setAttribute('type', 'image/png');
                        content.src = json.upload_content_info.src;
                        console.log("content_src:" + json.upload_content_info.src)
                    }
                    else {
                        alert("�̹����� ���� ���ε� �����մϴ�.");
                    }

                    this.appendChild(content);

                    //$(content).css("display", "block");
                    $(content).css("margin", "auto");
                    $(content).css("z-index", "100");
                    $(content).css("position", "relative");
                    $(this).css('opacity', '1');


                    if (this.offsetWidth > this.offsetHeight) {
                        $(content).css("width", "auto");
                        $(content).css("height", "80%");
                        $(content).css("top", "10%");
                    }
                    else {
                        $(content).css("width", "80%");
                        $(content).css("height", "auto");
                        $(this).css("width", this.offsetWidth+"px");
                        $(this).css("height", this.offsetHeight+"px");
                        $(this).css("display", "table-cell");
                        $(this).css("vertical-align", "middle");

                        
                    }
                    
                    if (touch_enable == true) {
                        if (window.navigator.msPointerEnabled) {
                            content.addEventListener("MSPointerDown", remove_upload, true); //false: leaf --> root ����
                        }
                        else {
                            content.addEventListener("touchstart", remove_upload, true); //false: leaf --> root ����  
                        }
                    }
                    else {
                        content.addEventListener("mousedown", remove_upload, true); //false: leaf --> root ����
                    }
                }

            });
        }
    }


    ws.onclose = function (e) {  // ���������� ������ ������..
        if ((e.code == '1000') || (e.code == '1001') || (e.code == '1006')) {//CLOSE_NORMAL

            var stop_msg_layer = document.createElement("DIV");

            $(stop_msg_layer).css("opacity", "0.9");
            $(stop_msg_layer).html('<div left="100px" top="200px"><center><p><font size="100" color="#FFFFFF"><b> Connection Lost </b></font></p></center></div>');

            $(stop_msg_layer).css("position", "absolute");
            $(stop_msg_layer).css("left", "0%");
            $(stop_msg_layer).css("top", "0%");
            $(stop_msg_layer).css("width", window.innerWidth);
            $(stop_msg_layer).css("height", window.innerHeight);
            $(stop_msg_layer).css("background-color", "black");

            document.body.appendChild(stop_msg_layer);
            timer_reload = setInterval(reload_page, RELOAD_CYCLE);
        }
    }

    ws.onerror = function (e) {
        console.log('Connection Error');
        console.log(e);
    }

    $(window).resize(function () {
        $(".upload_alphalayer").each(function () {
            if ($(this).css("display") == 'table-cell') {
                $(".upload_content").remove();
                $(".upload_alphalayer").css("width", "100%");
                $(".upload_alphalayer").css("height", "100%");
                $(".upload_alphalayer").css("line-height", "99%");
                $(".upload_alphalayer").css("display", "block");
            }
            
        });
        
    });
});

function heartbeat() {
    ws.send(JSON.stringify({ class: 'screen', type: 'heartbeat', screen_id: screenID }));
}
function reload_page() {
    ws = new window.WebSocket(websocketAddress);
    ws.binaryType = 'blob';

    ws.onopen = function (e) {
        window.location.reload(true);
    }
}

function draw_alphalayer(obj) {
    var alphalayer = document.createElement("DIV");
    $(alphalayer).addClass("alphalayer");
    //console.log(obj.childNodes[0]);
    alphalayer.id = $(obj).children()[0].getAttribute('data-contentid');
    alphalayer.setAttribute("data-content_type", $(obj).children()[0].tagName);
    alphalayer.setAttribute("data-contentid", alphalayer.id);
    alphalayer.setAttribute("data-mobile_src", $(obj).children()[0].getAttribute("data-mobile_src"));
    alphalayer.setAttribute("data-interaction_type", $(obj).children()[0].getAttribute("data-interaction_type"));
    if (alphalayer.getAttribute("data-interaction_type") == 'upload') {
        $(alphalayer).addClass("upload_alphalayer");
    }
    $(alphalayer).css("border", "0px");
    $(alphalayer).css("border-color", "red");
    $(alphalayer).css("border-style", "dotted");
    $(alphalayer).css("width", "100%");
    $(alphalayer).css("height", "100%");
    $(alphalayer).css("line-height", "100%");

    if (touch_enable == true) {
        if (window.navigator.msPointerEnabled) {
            alphalayer.addEventListener("MSPointerDown", animation_blink, false); //false: leaf --> root ����
            alphalayer.addEventListener("MSPointerUp", free_blink, false); //false: leaf --> root ����
        }
        else {
            alphalayer.addEventListener("touchstart", animation_blink, false); //false: leaf --> root ����
            alphalayer.addEventListener("touchend", free_blink, false); //false: leaf --> root ����
        }
    }
    else {
        alphalayer.addEventListener("mousedown", animation_blink, false); //false: leaf --> root ����
        alphalayer.addEventListener("mouseup", free_blink, false); //false: leaf --> root ����
    }

    obj.appendChild(alphalayer);
    alphalayer.appendChild(obj.children[0]);

    $(alphalayer.children[0]).load();

    return 0;

}
var touchEvent;
function animation_blink(event) {
    if(ContentPan_Operation_mode == 'set_CP_Coupling_Mode' ) {
        console.log("touch Start : " + this.id);

        console.log(event);

        if (ongoing_interaction[this.id] == undefined) {
            console.log("interaction timer Start ");
            ongoing_interaction[this.id] = { interaction_content: this.id, interaction_ID: '', operation: 'wait', touch_count: 1, touch_timer: ''};
            ongoing_interaction[this.id].touch_timer = setTimeout(get_interaction_id, TAP_HOLD_DELAY, this);
        }
        else if ( ongoing_interaction[this.id].operation == 'wait') {
            ongoing_interaction[this.id].touch_count++;
        }
        else {
            //delete ongoing_interaction[this.id];????
        }
    }
}

function free_blink() {
    if(ContentPan_Operation_mode == 'set_CP_Coupling_Mode' ) {
        console.log("touch End : " + this.id);
        if (ongoing_interaction[this.id] == undefined) {
            ;
        }
        else if ( ongoing_interaction[this.id].operation == 'wait') {
            ongoing_interaction[this.id].touch_count--;
            if(ongoing_interaction[this.id].touch_count == 0) {
                clearTimeout(ongoing_interaction[this.id].touch_timer);
                delete ongoing_interaction[this.id];
                console.log("interaction Break ");

                $( $(this).parent().children()[0]).trigger('touchstart');
                console.log($(this).parent().children()[0]);
                //$('#btn').trigger('click');
            }
        }
        else {
            ;//alert("operating...");
        }
    }
}

function get_interaction_id(obj) {
    if (ongoing_interaction[obj.id] != undefined) {
        if (ongoing_interaction[obj.id].operation == 'wait') {
            ongoing_interaction[obj.id] = { interaction_content: obj.id, interaction_ID: '', operation: 'active', touch_count: 1, touch_timer: '' };
            ws.send(JSON.stringify(
                                    {
                                        class: 'screen', type: 'get_interaction_ID',
                                        target: {
                                            screen_id: screenID,
                                            content_id: obj.id,
                                            mobile_content: {
                                                ContentID: obj.getAttribute("data-contentid"),
                                                src: $(obj).children()[0].getAttribute("src"),
                                                mobile_src: obj.getAttribute("data-mobile_src"),
                                                Content_Type: obj.getAttribute("data-content_type"),
                                                Interaction_Type: obj.getAttribute("data-interaction_type")
                                            }
                                        }
                                    }));
        }
        console.log($(obj).children()[0].getAttribute("src"));
        console.log("interaction msg Start");
    }
}


function remove_upload(event) {
    $(".upload_content").remove();
    //$(".alphalayer").each(function () {    });
    event.stopPropagation();
}

document.addEventListener("contextmenu", function (e) {
    e.preventDefault();
}, false);
/*
document.addEventListener("mousewheel", function (e) {
    e.preventDefault();
}, false);

document.addEventListener("touchmove", function (e) {
    e.preventDefault();
}, false);
*/