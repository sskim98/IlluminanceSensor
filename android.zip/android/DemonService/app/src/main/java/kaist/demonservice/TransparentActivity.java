package kaist.demonservice;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class TransparentActivity extends Activity {
    private TimerTask mFinishTask;
    private Timer mFinishTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transparent);

        WindowManager wmgr = (WindowManager)getApplicationContext().getSystemService(getApplicationContext().WINDOW_SERVICE);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

        mFinishTask = new TimerTask() {
            @Override
            public void run() {
                Intent intent = getIntent();
                String url = intent.getExtras().getString("url");
                openBrowser(url);
                finish();
            }
        };
        mFinishTimer = new Timer();
        mFinishTimer.schedule(mFinishTask, 300);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_transparent, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void openBrowser(String addr) {
        /*
        Intent browserIntent = new Intent(Intent.ACTION_VIEW);
        PackageManager packageManager = getPackageManager();
        Uri uri = Uri.parse(addr);
        browserIntent.setDataAndType(uri, "text/html");
        List<ResolveInfo> list = packageManager.queryIntentActivities(browserIntent, 0);
        for (ResolveInfo resolveInfo : list) {
            String activityName = resolveInfo.activityInfo.name;

            Log.e("activityName", activityName);
            if (activityName.contains("Browser")) {
                browserIntent =
                        packageManager.getLaunchIntentForPackage(resolveInfo.activityInfo.packageName);
                ComponentName comp =
                        new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
                browserIntent.setAction(Intent.ACTION_VIEW);
                browserIntent.addCategory(Intent.CATEGORY_BROWSABLE);
                browserIntent.setComponent(comp);
                browserIntent.setData(uri);
                startActivity(browserIntent);
                break;
            }
        } */
        Uri webpage = Uri.parse(addr);
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}
