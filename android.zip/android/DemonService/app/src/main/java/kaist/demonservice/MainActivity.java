package kaist.demonservice;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;


public class MainActivity extends ActionBarActivity implements CompoundButton.OnCheckedChangeListener {
    Switch t_btn;
    EditText ServerAddr;
    WifiManager wifiManager;
    WifiManager.WifiLock lock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t_btn = (Switch)findViewById(R.id.switch1);
        t_btn.setOnCheckedChangeListener(this);
        ServerAddr = (EditText)findViewById(R.id.editText);

        wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        lock = wifiManager.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LockTag");

        setIPFromFile();
        if(isServiceRunning()) {
            t_btn.setChecked(true);
        }
        else {
            t_btn.setChecked(false);
        }
        //Toast.makeText(getApplicationContext(), "Oncreate", Toast.LENGTH_SHORT).show();

        /*
        WindowManager wmgr = (WindowManager)getApplicationContext().getSystemService(getApplicationContext().WINDOW_SERVICE);
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        */
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public Boolean isServiceRunning() {
        String serviceName = "kaist.demonservice.MyService";
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo runningServiceInfo : activityManager.getRunningServices(Integer.MAX_VALUE)) {

            if (serviceName.equals(runningServiceInfo.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void setAddrToFile() {
        try {
            File file = getFileStreamPath("ServerAddr.txt");
            FileOutputStream fos = new FileOutputStream(file);
            Writer out = new OutputStreamWriter(fos, "UTF-8");
            out.write(ServerAddr.getText().toString());
            out.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void setIPFromFile() {
        try {
            String ipaddr="";
            File file = getFileStreamPath("ServerAddr.txt");
            if(file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                Reader in = new InputStreamReader(fis);
                int size = fis.available();
                char[] buffer = new char[size];
                in.read(buffer);
                in.close();
                ipaddr = new String(buffer);
                ServerAddr.setText(ipaddr);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        Intent intents = new Intent(getApplicationContext(), MyService.class);
        intents.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        setAddrToFile();

        if(isChecked) {
            startService(intents);
            lock.acquire();
        }
        else {
            stopService(intents);
            if(lock.isHeld()) {
                lock.release();
            }
        }
    }
}
