package kaist.demonservice;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.inputmethodservice.InputMethodService;
import android.media.AudioManager;
import android.media.SoundPool;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.Toast;
import android.webkit.WebChromeClient;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class MyService extends Service implements SensorEventListener {
    public long[] changeTimes = new long[4];
    public int counter = 0;
    public int mode = 0;

    public WebView wv;
    private final Handler handler = new Handler();
    private final AndroidBridge androidApp = new AndroidBridge();
    SensorManager m_sensor_manager;
    public Sensor m_light_sensor;
    public int illuminanceData = 0;
    SoundPool m_soundpool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0 );
    int m_dingdong;
    int m_shutter;
    Vibrator mVib = null;
    Vibrator mVibrator = null;
    int mApp_status = 0;
    long start_time = 0, end_time;
    private String fileIndex;
    Boolean isAppRunning = false;
    int SENSOR_DATA_MULTIPLY = 1;
    String prefix_file = "";
    PowerManager.WakeLock screenWakeLock;
    WifiManager.WifiLock wifiLock;
    String ServerAddress = "";
    private TimerTask mWakeLockTask;
    private Timer mWakeLockTimer;
    private Boolean status_WakeLock = false;


    @Override
    public void onCreate() {
        ServerAddress = getAddrFromFile();

        /*
        ConnectivityManager manager =
                (ConnectivityManager)getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);

        if (mobile.isConnected() || wifi.isConnected()){
            // WIFI, 3G 어느곳에도 연결되지 않았을때
            Toast.makeText(getBaseContext(), "connection success",
                    Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getBaseContext(), "connection fail",
                    Toast.LENGTH_SHORT).show();
        }
*/
        Toast.makeText(getBaseContext(), "START ContentPan", Toast.LENGTH_SHORT).show();



        changeTimes[0]= 0;changeTimes[1]= 0;changeTimes[2]= 0;changeTimes[3]= 0;

        m_sensor_manager = (SensorManager)getSystemService(SENSOR_SERVICE);
        m_light_sensor = m_sensor_manager.getDefaultSensor(Sensor.TYPE_LIGHT);
        m_sensor_manager.registerListener(this, m_light_sensor,SensorManager.SENSOR_DELAY_GAME);
        /*
        Intent intents = new Intent(getApplicationContext(), MainActivity.class);
        intents.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intents);
*/


        //wv = (WebView)findViewById(R.id.webview);
        wv = new WebView(this);
        //WebView.setWebContentsDebuggingEnabled(true);
        wv.getSettings().setJavaScriptEnabled(true);
        WebView.setWebContentsDebuggingEnabled(true);
        wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.getSettings().setGeolocationEnabled(true);
        wv.getSettings().setUseWideViewPort(true);
        wv.getSettings().setLoadWithOverviewMode(true);
        wv.getSettings().setSupportZoom(true);
        wv.getSettings().setBuiltInZoomControls(true);
        wv.getSettings().setDisplayZoomControls(false);
        wv.getSettings().setSupportMultipleWindows(true);
        wv.getSettings().setDatabaseEnabled(true);
        wv.getSettings().setAppCacheEnabled(true);
        wv.getSettings().setMediaPlaybackRequiresUserGesture(false); //사용자 입력 없이 비디오의 autoplay 가능하게 하는 함수

        wv.setWebChromeClient(new UserClient());

        wv.setWebViewClient( new WebViewClient(){
            public boolean shouldOverrideUrlLoading(WebView view, String url){
                view.loadUrl(url);
                return false;
            }
            public void onPageFinished(WebView view, String url) {
                //Toast.makeText(getApplicationContext(), "ContentPan is ready!", Toast.LENGTH_SHORT).show();
            }
        });

        wv.addJavascriptInterface(androidApp, "androidApp");

        //wv.loadUrl(ServerAddress);
        m_dingdong = m_soundpool.load(this, R.raw.bell, 1);
        m_shutter = m_soundpool.load(this, R.raw.shu, 1);
        mVib = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
        mVibrator = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        wv.loadUrl(ServerAddress);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "STOP ContentPan",
                Toast.LENGTH_SHORT).show();
        wv.loadUrl("about:blank");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    final class UserClient extends WebChromeClient {
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            // Always grant permission since the app itself requires location
            // permission and the user has therefore already granted it
            callback.invoke(origin, true, false);
        }
        public void onPageFinished(WebView view, String url) {
            Toast.makeText (getApplicationContext(), "ContentPan is ready!", Toast.LENGTH_SHORT).show();
            //wv.loadUrl("javascript:(function() { document.getElementsByTagName('video')[0].play(); })()");
            //wv.loadUrl("javascript:(function() { alert('test'); var currentSlideChild = galleryParent.getSlide(galleryParent.activeIndex).childNodes[0]; if(currentSlideChild != 'undefined') { if(currentSlideChild.tagName == 'VIDEO') { alert('test'); currentSlideChild.load();}}    })()");
        }
    }


    private class AndroidBridge {
        @JavascriptInterface
        public int getIlluminanceData() {
            return illuminanceData;
        }
        @JavascriptInterface
        public void sound_bell() {
            end_time = SystemClock.uptimeMillis();
            mApp_status++;
            m_soundpool.play(m_dingdong, 1, 1, 0, 0, 1);
        }
        @JavascriptInterface
        public void sound_shutter() {
            m_soundpool.play(m_shutter, 1, 1, 0, 0, 1);
        }
        @JavascriptInterface
        public void vibrator() {
            mVib.vibrate(1000);
        }
        @JavascriptInterface
        public void vibrator_short() {
            long[] pattern = {0,200,100,200,100,300};
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            mVibrator.vibrate(pattern, -1);
        }
        @JavascriptInterface
        public int get_Sensor_Stabilizing_Time() {
            if(Build.BRAND.contentEquals("samsung")) {
                String a = Build.MODEL;
                //Toast.makeText(getApplicationContext(), a , Toast.LENGTH_LONG).show();
                if(Build.MODEL.contentEquals("SHV-E330L")) {
                    SENSOR_DATA_MULTIPLY = 3;
                }
                else {
                    SENSOR_DATA_MULTIPLY = 2;
                }

                return 300; // 갤럭시 오전에 220으로 가끔 안됨
            }
            return 400;
        }
        @JavascriptInterface
        public void set_log_name() {
            prefix_file = "_RID";
        }
        @JavascriptInterface
        public void openlink(String url) {
            //Toast.makeText(getBaseContext(),url, Toast.LENGTH_SHORT).show();
            acquireWakeLock(getApplicationContext());

            Intent intent = new Intent(getApplicationContext(), TransparentActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            if(url.contains("/mobile/M_camera.html")) {
                intent.putExtra("url", url + "/" + System.currentTimeMillis());
            }
            else {
                intent.putExtra("url", url);
            }
            startActivity(intent);

            //openBrowser(url+"/"+System.currentTimeMillis());

            if (status_WakeLock == true) {
                mWakeLockTimer.cancel();
            }
            mWakeLockTask = new TimerTask() {
                @Override
                public void run() {
                    releaseWakeLock();
                    status_WakeLock = false;
                }
            };
            mWakeLockTimer = new Timer();
            mWakeLockTimer.schedule(mWakeLockTask, 5000);
            status_WakeLock = true;
        }
    }

    public void onAccuracyChanged(Sensor arg0, int arg1) {
        // TODO Auto-generated method stub

    }

    public void onSensorChanged(SensorEvent event) {
        // TODO Auto-generated method stub
        // 정확도가 낮은 측정값인 경우
        if (event.accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE) {
        }

        if(event.sensor.getType() == Sensor.TYPE_LIGHT) {
            illuminanceData = (int) ( event.values[0] * SENSOR_DATA_MULTIPLY);
            //wv.loadUrl("javascript:Msg_from_AndroidApp('" + illuminanceData + "')");
        }
        /*
        if(event.sensor.getType() == Sensor.TYPE_LIGHT) {
            if( (int)(event.values[0]) - illuminanceData > 100) {
                if(mode == 0) {
                    if (counter < 4) {
                        changeTimes[counter++] = System.currentTimeMillis();
                        mode = 1;
                    }
                }
            }
            else if( (int)(event.values[0]) - illuminanceData < -100  ) {
                if(mode == 1) {
                    if (counter < 4) {
                        changeTimes[counter++] = System.currentTimeMillis();
                        mode = 0;
                    }
                }
            }
            illuminanceData = (int)(event.values[0]);

            for(int i=0; i<counter; i++) {
                if( changeTimes[i] < System.currentTimeMillis()-4000) {
                    for(int j=i; j<4; j++) {
                        changeTimes[j] = changeTimes[j+1];

                    }
                    counter--;
                }
            }
            if(counter == 4) {
                openBrowser();
                counter = 0;
            }

            //wv.loadUrl("javascript:Msg_from_AndroidApp('" + illuminanceData + "')");
        }
        */
    }

    public void openBrowser(String addr) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW);
        PackageManager packageManager = getPackageManager();
        Uri uri = Uri.parse(addr);
        browserIntent.setDataAndType(uri, "text/html");
        List<ResolveInfo> list = packageManager.queryIntentActivities(browserIntent, 0);
        for (ResolveInfo resolveInfo : list) {
            String activityName = resolveInfo.activityInfo.name;

            Log.e("activityName", activityName);
            if (activityName.contains("Browser")) {
                browserIntent =
                        packageManager.getLaunchIntentForPackage(resolveInfo.activityInfo.packageName);
                ComponentName comp =
                        new ComponentName(resolveInfo.activityInfo.packageName, resolveInfo.activityInfo.name);
                browserIntent.setAction(Intent.ACTION_VIEW);
                browserIntent.addCategory(Intent.CATEGORY_BROWSABLE);
                browserIntent.setComponent(comp);
                browserIntent.setData(uri);
                startActivity(browserIntent);
                break;
            }
        }
    }

    private void acquireWakeLock(Context context) {
        PowerManager pm = (PowerManager)context.getSystemService
                (Context.POWER_SERVICE);
        screenWakeLock = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK
                | PowerManager.ACQUIRE_CAUSES_WAKEUP
                , context.getClass().getName());


        if (screenWakeLock != null) {
            screenWakeLock.acquire();
        }
    }

    private void releaseWakeLock() {
        if (screenWakeLock != null) {
            screenWakeLock.release();
            screenWakeLock = null;
        }
    }

    public String getAddrFromFile() {
        String text = null;
        try {
            File file = getFileStreamPath("ServerAddr.txt");
            FileInputStream fis = new FileInputStream(file);
            Reader in = new InputStreamReader(fis);
            int size = fis.available();
            char[] buffer = new char[size];
            in.read(buffer);
            in.close();

            text = new String(buffer);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return text;
    }
}
