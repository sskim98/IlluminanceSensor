package kaist.demonservice;

import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.KeyEvent;
import android.widget.Toast;

public class MyServiceReceiver extends BroadcastReceiver {
    private KeyguardManager km = null;
    private KeyguardManager.KeyguardLock keyLock = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent intents = new Intent(context, MyService.class);

        if(intent.getAction().equals(Intent.ACTION_BOOT_COMPLETED)) {
            //context.startService(new Intent(context,MyService.class));
            //intents.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startService(intents);
        }

        else if(intent.getAction().equals(ConnectivityManager.CONNECTIVITY_ACTION) ) {
            //Toast.makeText(context, "Connectivity", Toast.LENGTH_SHORT).show();
            NetworkInfo info = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
            NetworkInfo.DetailedState state = info.getDetailedState();
            if (state == NetworkInfo.DetailedState.CONNECTED) {
                context.startService(intents);
            } else if (state == NetworkInfo.DetailedState.DISCONNECTED) {
                context.stopService(intents);
                Toast.makeText(context, "Connectivity", Toast.LENGTH_SHORT).show();
            }
        }

        else if(intent.getAction().equals(Intent.ACTION_SCREEN_OFF) ) {
            if (km == null)
                km = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);

            if (keyLock == null)
                keyLock = km.newKeyguardLock(Context.KEYGUARD_SERVICE);

            keyLock.disableKeyguard();
        }

        /*
        else if(intent.getAction().equals(intent.ACTION_PACKAGE_ADDED)) {
            context.startService(intents);
        }
        else if(intent.getAction().equals(intent.ACTION_PACKAGE_REPLACED)) {
            context.startService(intents);
        }
        /*
        else {
            int volume = (Integer)intent.getExtras().get("android.media.EXTRA_VOLUME_STREAM_VALUE");
            if(volume == 0) {
                context.stopService(intents);
            }
            else {
                context.startService(intents);
            }
        }
        */
        /*
        else if (Intent.ACTION_MEDIA_BUTTON.equals(intent.getAction())) {
            KeyEvent event = (KeyEvent)intent.getParcelableExtra(Intent.EXTRA_KEY_EVENT);
            Intent intents = new Intent(context, MyService.class);

            if (KeyEvent.KEYCODE_VOLUME_DOWN == event.getKeyCode()) {
                context.startService(intents);
                Toast.makeText(context, "STOP MyService",
                        Toast.LENGTH_SHORT).show();
            }
            else if(KeyEvent.KEYCODE_VOLUME_UP == event.getKeyCode()) {
                context.startService(intents);

            }

        }
        */
    }
}